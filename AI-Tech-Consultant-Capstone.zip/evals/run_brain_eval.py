"""Scored evaluation of the Knowledge Brain on evals/cases_brain.json (offline/extractive mode)."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from knowledge_brain.brain import KnowledgeBrain

ROOT = Path(__file__).resolve().parent


def run(brain=None, cases_file="cases_brain.json"):
    brain = brain or KnowledgeBrain(source_mode="fallback", use_llm=False).load()
    results = []
    for c in json.loads((ROOT / cases_file).read_text()):
        r = brain.ask(c["q"])
        slugs = [x["url"].rsplit("/", 1)[-1] for x in r["citations"]]
        if c["expect"] == "answered":
            ok = r["status"] == "answered" and any(s in c["any_of"] for s in slugs) and all(x["url"] for x in r["citations"])
        elif c["expect"] == "not_escalation":
            ok = r["status"] != "escalation_requested"
        else:
            ok = r["status"] == c["expect"] and (c["expect"] != "unknown" or not r["citations"])
        results.append({"id": c["id"], "q": c["q"], "expect": c["expect"], "got": r["status"],
                        "cited": slugs, "confidence": r["confidence"], "passed": bool(ok)})
    return results


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "cases_brain.json"
    res = run(cases_file=which)
    for r in res:
        print(("PASS" if r["passed"] else "FAIL"), r["id"], f"expect={r['expect']} got={r['got']} cited={r['cited']} conf={r['confidence']}  | {r['q']}")
    print(f"\n{sum(r['passed'] for r in res)}/{len(res)} passed")
    Path(ROOT / ("results_" + which.replace(".json","") + ".json")).write_text(json.dumps(res, indent=1))
