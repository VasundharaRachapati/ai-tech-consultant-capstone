"""Run every evaluation and write evals/RESULTS.md + evals/results.json. Numbers in EVALS.md come from here.
    python evals/run_evals.py"""
import json, re, subprocess, sys, time
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from fastapi.testclient import TestClient
from knowledge_brain.brain import KnowledgeBrain
from knowledge_brain.api import create_app
from common.brain_client import BrainClient
from inbox_agent.classifier import classify
from inbox_agent.agent import InboxAgent
from inbox_agent import simulate
from evals.run_brain_eval import run as run_brain


def brain_metrics(res):
    ans = [r for r in res if r["expect"] == "answered"]; unk = [r for r in res if r["expect"] == "unknown"]
    return {"total": len(res), "passed": sum(r["passed"] for r in res),
            "answerable": len(ans), "answerable_correct": sum(r["passed"] for r in ans),
            "false_unknown": sum(r["got"] == "unknown" for r in ans),
            "wrong_doc": sum(r["got"] == "answered" and not r["passed"] for r in ans),
            "unanswerable": len(unk), "fabricated_answers": sum(r["got"] == "answered" for r in unk),
            "failures": [(r["id"], r["q"], r["got"]) for r in res if not r["passed"]]}


def pytest_counts(path):
    out = subprocess.run([sys.executable, "-m", "pytest", "-q", path], cwd=ROOT, capture_output=True, text=True).stdout
    return out.strip().splitlines()[-1]


def main():
    R = {"generated": time.strftime("%Y-%m-%d %H:%M"), "mode": "offline/extractive, synthetic fallback corpus"}
    b = KnowledgeBrain(source_mode="fallback", use_llm=False).load()
    R["brain_main"] = brain_metrics(run_brain(b, "cases_brain.json"))
    R["brain_heldout"] = brain_metrics(run_brain(b, "cases_brain_heldout.json"))

    emails = json.loads((ROOT / "samples" / "emails.json").read_text())
    ok = [classify(e["subject"] + ". " + e["text"])[0] == e["true_category"] for e in emails]
    hard = json.loads((ROOT / "evals" / "cases_inbox_hard.json").read_text())
    got = [(h["id"], h["label"], classify(h["text"])[0]) for h in hard]
    R["inbox_classifier_synthetic"] = {"total": len(ok), "correct": sum(ok)}
    R["inbox_classifier_hard"] = {"total": len(got), "correct": sum(1 for _, l, g in got if l == g),
                                  "misses": [(i, l, g) for i, l, g in got if l != g]}
    ag = InboxAgent(BrainClient(client=TestClient(create_app(b))))
    sim = simulate.run(ag, emails)
    how = [x for x in sim["log"] if x["category"] == "how_to"]
    R["inbox_simulation"] = {"emails": len(emails), "decisions": dict(Counter(x["decision"] for x in sim["log"])),
                             "how_to_total": len(how), "how_to_eligible": sum(1 for x in how if x["eligible"]),
                             "how_to_brain_unknown": sum(1 for x in how if x["brain_status"] != "answered"),
                             "events_how_to": [e["kind"] for e in sim["events"] if e["category"] == "how_to"]}
    R["pytest"] = {f: pytest_counts(f"tests/{f}.py") for f in ("test_brain", "test_inbox", "test_sow")}
    (ROOT / "evals" / "results.json").write_text(json.dumps(R, indent=1))
    L = [f"# Evaluation results (auto-generated {R['generated']})", "", f"Mode: {R['mode']}", "", "```json", json.dumps(R, indent=1), "```"]
    (ROOT / "evals" / "RESULTS.md").write_text("\n".join(L))
    print(json.dumps(R, indent=1))


if __name__ == "__main__":
    main()
