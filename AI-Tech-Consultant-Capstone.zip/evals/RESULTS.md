# Evaluation results (auto-generated 2026-10-23 05:39)

Mode: offline/extractive, synthetic fallback corpus

```json
{
 "generated": "2026-10-23 05:39",
 "mode": "offline/extractive, synthetic fallback corpus",
 "brain_main": {
  "total": 37,
  "passed": 34,
  "answerable": 24,
  "answerable_correct": 21,
  "false_unknown": 3,
  "wrong_doc": 0,
  "unanswerable": 9,
  "fabricated_answers": 0,
  "failures": [
   [
    "B02",
    "Can I offer a free plan to members?",
    "unknown"
   ],
   [
    "B10",
    "How do I accept credit cards with Stripe?",
    "unknown"
   ],
   [
    "B13",
    "What happens if I upgrade a plan in the middle of a billing cycle?",
    "unknown"
   ]
  ]
 },
 "brain_heldout": {
  "total": 11,
  "passed": 10,
  "answerable": 8,
  "answerable_correct": 7,
  "false_unknown": 1,
  "wrong_doc": 0,
  "unanswerable": 3,
  "fabricated_answers": 0,
  "failures": [
   [
    "V01",
    "How can I let new members sign up without waiting for approval?",
    "unknown"
   ]
  ]
 },
 "inbox_classifier_synthetic": {
  "total": 77,
  "correct": 77
 },
 "inbox_classifier_hard": {
  "total": 20,
  "correct": 12,
  "misses": [
   [
    "H02",
    "billing",
    "sales_inquiry"
   ],
   [
    "H04",
    "other",
    "how_to"
   ],
   [
    "H05",
    "bug_report",
    "how_to"
   ],
   [
    "H06",
    "billing",
    "cancellation"
   ],
   [
    "H09",
    "billing",
    "how_to"
   ],
   [
    "H11",
    "other",
    "feature_request"
   ],
   [
    "H15",
    "complaint",
    "other"
   ],
   [
    "H18",
    "feature_request",
    "how_to"
   ]
  ]
 },
 "inbox_simulation": {
  "emails": 77,
  "decisions": {
   "needs_review": 70,
   "auto_sent": 4,
   "archived_spam": 3
  },
  "how_to_total": 47,
  "how_to_eligible": 34,
  "how_to_brain_unknown": 13,
  "events_how_to": [
   "edit_learned",
   "streak_reset",
   "edit_learned",
   "streak_reset",
   "auto_send_enabled",
   "audit_correction_learned",
   "auto_send_suspended_rolled_back"
  ]
 },
 "pytest": {
  "test_brain": "55 passed, 4 xfailed in 0.36s",
  "test_inbox": "100 passed in 0.51s",
  "test_sow": "44 passed in 1.17s"
 }
}
```