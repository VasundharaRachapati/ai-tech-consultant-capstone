# Proposal and Scope of Work - Harbor & Pine Realty

> **DRAFT - NOT APPROVED. Do not send to the client until a human has approved this document.**

_Generated 2026-10-23 from: 01_discovery_call.txt, 02_requirements_workshop.txt, 03_review_session.txt, 04_follow_up_email.txt_

## 1. Summary

Based on 4 client conversations we propose a directory platform configured to your needs. Client budget: $16,000; target launch: February 28.

Constraint changes over time: budget 18000 -> 16000 (Follow-up Email); deadline January 31 -> February 28 (Follow-up Email)

## 2. In scope

- **Membership plans / tiers** - docs: [Create a Membership Plan](local://fallback/create-membership-plan)
- **Bulk listing import (CSV)** - docs: [Import Members from a CSV File](local://fallback/import-members-csv)
- **Custom domain and HTTPS** - docs: [Connect a Custom Domain](local://fallback/custom-domain-setup)
- **Search by city with map results** - docs: [Configure the Search Results Page](local://fallback/search-results-layout), [Add a Google Maps API Key](local://fallback/google-maps-api-key)
- **Card payments (Stripe)** - docs: [Connect Stripe for Membership Payments](local://fallback/payment-gateway-stripe)
- **Lead forms and routing** - docs: [Lead Forms and Lead Matching](local://fallback/lead-forms-and-matching)
- **Branded email notifications** - docs: [Customize Email Templates](local://fallback/email-templates)
- **SEO city landing pages** - docs: [SEO Settings and Meta Tags](local://fallback/seo-settings-meta-tags)
- **Staff accounts and permissions** - docs: [Staff Accounts, Roles, and Permissions](local://fallback/user-roles-permissions)
- **Nightly backups** - docs: [Backups and Restore](local://fallback/backups-and-restore)
- **Listing approval workflow** - docs: [Approve or Reject New Member Listings](local://fallback/member-listing-approval)
- **Webhook / Zapier CRM sync** - docs: [Webhooks and the API](local://fallback/webhooks-and-api)

## 3. Out of scope (requested but not included)

- **Native iOS/Android app** - Native mobile apps are separate app-store development, not configuration of the directory platform. Knowledge Brain found no documentation of this capability.
- **SAP / ERP payment integration** - Custom ERP integration needs bespoke development and access to the client's SAP environment. Knowledge Brain found no documentation of this capability.
- **WhatsApp chatbot** - A conversational chatbot is a separate AI/bot project, not a documented platform feature. Knowledge Brain found no documentation of this capability.

## 4. Removed at client request

- reviews: "To confirm: we no longer need the star reviews feature for launch, please drop it from scope."

## 5. Requests needing a human decision (not estimated)

- "Can you also add a waitlist for agents when a city is already full?" - Not found in documentation - needs human decision (custom development or out of scope). Not included in hours.
- "We would also like members to be able to export their leads to Excel." - Not found in documentation - needs human decision (custom development or out of scope). Not included in hours.

## 6. Tasks and estimated hours

| Feature | Task | Hours |
|---|---|---|
| membership_plans | Design plan structure and feature limits | 3 |
| membership_plans | Configure free/paid plans | 4 |
| membership_plans | Signup page and plan visibility | 3 |
| membership_plans | Test upgrade/downgrade flows | 2 |
| csv_import | Clean and map source spreadsheet | 5 |
| csv_import | Run test import and fix rejects | 3 |
| csv_import | Run full import and verify | 3 |
| custom_domain_ssl | DNS records and domain settings | 3 |
| custom_domain_ssl | SSL verification and force-HTTPS | 2 |
| custom_domain_ssl | Redirect testing | 1 |
| search_map | Search layout and filters (city, category) | 5 |
| search_map | Google Maps API key and map view | 4 |
| search_map | Result sorting and featured placement | 3 |
| search_map | Cross-device testing | 2 |
| payments | Stripe account connection (test mode) | 3 |
| payments | Paid plan checkout testing | 4 |
| payments | Failed-renewal and grace-period setup | 3 |
| payments | Go-live switch to live keys | 1 |
| lead_routing | Lead form fields and embedding | 4 |
| lead_routing | Matching rules (city + service) | 6 |
| lead_routing | Lead storage and admin review | 3 |
| lead_routing | Testing with sample leads | 3 |
| email_notifications | Draft branded copy for templates | 3 |
| email_notifications | Configure templates and placeholders | 3 |
| email_notifications | SPF/DKIM and test sends | 2 |
| seo_city_pages | Title/meta templates | 3 |
| seo_city_pages | City page template and generation | 6 |
| seo_city_pages | Sitemap submission | 1 |
| seo_city_pages | Content QA | 2 |
| staff_roles | Define roles | 2 |
| staff_roles | Create staff accounts and test restrictions | 3 |
| staff_roles | Document access policy | 1 |
| backups | Confirm backup schedule and retention | 1 |
| backups | Restore drill | 2 |
| approval_workflow | Enable approval setting | 1 |
| approval_workflow | Approval email wording | 1 |
| approval_workflow | Moderator training notes | 1 |
| webhooks_crm | Webhook configuration for signup event | 3 |
| webhooks_crm | Zapier zap to CRM and mapping | 4 |
| webhooks_crm | End-to-end test | 2 |
| overhead | Project kickoff and discovery wrap-up | 6 |
| overhead | Training and handover | 6 |
| overhead | Testing and user acceptance (15% of feature hours) | 16.6 |
| overhead | Project management (10% of feature hours) | 11.1 |

Subtotal 150.7 h + 15% contingency (22.6 h) = **173.3 h**. At the assumed $95/h: **$16,464** vs budget $16,000 - **EXCEEDS** budget.

## 7. Assumptions

- Hour estimates are planning assumptions from a fixed catalog, not measured data.
- Hourly rate $95 is a placeholder (set SOW_HOURLY_RATE).
- Platform capabilities were checked against the documentation available to the Knowledge Brain (local synthetic fallback unless a live crawl succeeded).

## 8. Open items for the human approver

- [ ] Unestimated request needs human decision: "Can you also add a waitlist for agents when a city is already full?"
- [ ] Unestimated request needs human decision: "We would also like members to be able to export their leads to Excel."
- [ ] Estimated cost $16,464 EXCEEDS client budget $16,000 - discuss scope trade-offs.
