"""KnowledgeBrain: retrieval + grounded answer + honesty gate + escalation + update detection."""
from __future__ import annotations
import os, re
from pathlib import Path
from .crawler import Document, load_documents
from .index import BM25Index
from .store import Store
from .textutil import sentences, tokens

MIN_COVERAGE = float(os.getenv("BRAIN_MIN_COVERAGE", "0.60"))   # share of query IDF mass found in best chunk
STRICT_COVERAGE = float(os.getenv("BRAIN_STRICT_COVERAGE", "0.85"))  # used if the question has an unseen distinctive word
MIN_SCORE = float(os.getenv("BRAIN_MIN_SCORE", "2.0"))          # BM25 floor
HUMAN_RE = re.compile(r"\b(human|real person|(live|human|support) agent|representative|talk to (a |an )?(someone|person)|"
                      r"speak (to|with) (a |an )?(someone|person|human)|support team)\b", re.I)

UNKNOWN_MSG = ("I couldn't find this in the documentation I have access to, so I don't want to guess. "
               "I can pass your question to a human support specialist - just confirm and I'll open a ticket.")


class KnowledgeBrain:
    def __init__(self, source_mode: str | None = None, db_path: str | Path = ":memory:",
                 fallback_dir: Path | None = None, use_llm: bool | None = None):
        self.source_mode, self.fallback_dir = source_mode, fallback_dir
        self.store = Store(db_path)
        self.use_llm = bool(os.getenv("ANTHROPIC_API_KEY")) if use_llm is None else use_llm
        self.docs: dict[str, Document] = {}
        self.index: BM25Index | None = None
        self.source = "none"

    # ---------- ingestion ----------
    def load(self):
        docs, self.source = load_documents(self.source_mode, self.fallback_dir)
        self._set_docs(docs)
        return self

    def _set_docs(self, docs: list[Document]):
        self.docs = {d.url: d for d in docs}
        self.index = BM25Index(docs)

    def refresh(self) -> dict:
        """Re-ingest and report added / changed / removed pages (by content hash)."""
        old = {u: d.hash for u, d in self.docs.items()}
        new_docs, source = load_documents(self.source_mode, self.fallback_dir)
        new = {d.url: d.hash for d in new_docs}
        diff = {
            "added": sorted(set(new) - set(old)),
            "removed": sorted(set(old) - set(new)),
            "changed": sorted(u for u in new if u in old and new[u] != old[u]),
        }
        diff["unchanged"] = len(set(new) & set(old)) - len(diff["changed"])
        diff["source"] = source
        diff["reindexed"] = bool(diff["added"] or diff["removed"] or diff["changed"])
        if diff["reindexed"]:
            self.source = source
            self._set_docs(new_docs)
        self.store.log_update(source, diff)
        return diff

    # ---------- answering ----------
    def ask(self, question: str) -> dict:
        question = (question or "").strip()
        base = {"question": question, "corpus_source": self.source, "answer_mode": "extractive"}
        if not question:
            return base | {"status": "unknown", "answer": "Please ask a question.", "confidence": 0.0,
                           "citations": [], "escalation": {"offered": False}}
        if HUMAN_RE.search(question):
            tid = self.store.add_escalation(question, reason="user asked for a human")
            return base | {"status": "escalation_requested", "confidence": 0.0, "citations": [],
                           "answer": f"Of course - I've opened ticket #{tid} so a human support specialist can follow up.",
                           "escalation": {"offered": True, "ticket_id": tid}}

        hits = self.index.search(question, k=4)
        if not hits:
            return self._unknown(base, question, [])
        best_score, best = hits[0]
        cov, n_unseen = self.index.coverage(question, best)
        confidence = round(min(1.0, cov) * min(1.0, best_score / 8.0), 3)
        needed = STRICT_COVERAGE if n_unseen else MIN_COVERAGE
        if cov < needed or best_score < MIN_SCORE:
            return self._unknown(base, question, hits, confidence)

        # Use top chunk, plus the second only if it is from a different doc and also relevant.
        used = [best]
        if len(hits) > 1 and hits[1][1].url != best.url and hits[1][0] >= 0.7 * best_score:
            used.append(hits[1][1])
        answer, mode = self._compose(question, used)
        cites, seen = [], {}
        for ch in used:
            if ch.url not in seen:
                seen[ch.url] = len(seen) + 1
                cites.append({"n": seen[ch.url], "title": ch.title, "url": ch.url,
                              "snippet": ch.text[:160].rstrip() + ("..." if len(ch.text) > 160 else "")})
        return base | {"status": "answered", "answer": answer, "confidence": confidence,
                       "citations": cites, "answer_mode": mode, "escalation": {"offered": False}}

    def _unknown(self, base, question, hits, confidence=0.0):
        related = []
        for _, ch in hits[:2]:
            if ch.url not in [r["url"] for r in related]:
                related.append({"title": ch.title, "url": ch.url})
        return base | {"status": "unknown", "answer": UNKNOWN_MSG, "confidence": confidence, "citations": [],
                       "related_unverified": related,
                       "escalation": {"offered": True, "how": "POST /escalate with this question"}}

    def _compose(self, question: str, chunks) -> tuple[str, str]:
        if self.use_llm:
            try:
                return self._llm_answer(question, chunks), "llm"
            except Exception as e:
                print(f"[brain] LLM call failed ({type(e).__name__}); using extractive answer")
        q = set(tokens(question))
        picked = []
        for ci, ch in enumerate(chunks):
            sents = sentences(ch.text)
            scored = sorted(((sum(self.index.idf(t) for t in q & set(tokens(s))), i, s)
                             for i, s in enumerate(sents)), reverse=True)
            keep = sorted(i for sc, i, s in scored[:3] if sc > 0)
            picked.append((ci, [sents[i] for i in keep]))
        parts = []
        for n, (ci, sents) in enumerate(picked, 1):
            if sents:
                parts.append(" ".join(sents) + f" [{n}]")
        return "\n\n".join(parts), "extractive"

    def _llm_answer(self, question, chunks) -> str:
        import anthropic
        client = anthropic.Anthropic()
        src = "\n\n".join(f"[{i}] {c.title}\n{c.text}" for i, c in enumerate(chunks, 1))
        msg = client.messages.create(
            model=os.getenv("BRAIN_LLM_MODEL", "claude-sonnet-4-5"), max_tokens=500,
            system=("You answer support questions using ONLY the numbered sources. Cite with [n] after claims. "
                    "If the sources do not contain the answer, reply exactly: INSUFFICIENT. Never invent steps."),
            messages=[{"role": "user", "content": f"Sources:\n{src}\n\nQuestion: {question}"}])
        text = msg.content[0].text.strip()
        if text.startswith("INSUFFICIENT"):
            raise RuntimeError("LLM judged sources insufficient")
        return text

    def escalate(self, question: str, contact: str = "", reason: str = "user confirmed") -> dict:
        tid = self.store.add_escalation(question, contact, reason)
        return {"ticket_id": tid, "status": "open"}
