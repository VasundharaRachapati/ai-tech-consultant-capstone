"""BM25 retrieval over document chunks, plus an IDF-weighted 'coverage' score
used to decide when the Brain should say 'I don't know'."""
from __future__ import annotations
import math
from collections import Counter
from dataclasses import dataclass
from .crawler import Document
from .textutil import tokens, COMMON_STEMS


@dataclass
class Chunk:
    url: str
    title: str
    text: str
    toks: list[str]


def chunk_document(doc: Document, target_words: int = 90) -> list[Chunk]:
    chunks, buf = [], []
    def flush():
        if buf:
            text = " ".join(buf)
            chunks.append(Chunk(doc.url, doc.title, text, tokens(doc.title) * 2 + tokens(text)))
    count = 0
    for para in [p.strip() for p in doc.text.split("\n\n") if p.strip()]:
        buf.append(para); count += len(para.split())
        if count >= target_words:
            flush(); buf, count = [], 0
    flush()
    return chunks


class BM25Index:
    def __init__(self, docs: list[Document], k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.chunks = [c for d in docs for c in chunk_document(d)]
        self.N = len(self.chunks)
        self.df: Counter = Counter()
        for c in self.chunks:
            self.df.update(set(c.toks))
        self.avgdl = sum(len(c.toks) for c in self.chunks) / max(self.N, 1)
        self.tf = [Counter(c.toks) for c in self.chunks]
        self.max_idf = math.log(1 + (self.N + 0.5) / 0.5)

    def idf(self, term: str) -> float:
        n = self.df.get(term)
        if not n:
            return self.max_idf          # unseen terms count as maximally informative
        return math.log(1 + (self.N - n + 0.5) / (n + 0.5))

    def search(self, query: str, k: int = 5) -> list[tuple[float, Chunk]]:
        q = tokens(query)
        scored = []
        for i, c in enumerate(self.chunks):
            dl, s = len(c.toks), 0.0
            for t in set(q):
                f = self.tf[i].get(t, 0)
                if f:
                    s += self.idf(t) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
            if s > 0:
                scored.append((s, c))
        scored.sort(key=lambda x: -x[0])
        return scored[:k]

    def coverage(self, query: str, chunk: Chunk) -> tuple[float, int]:
        """Return (coverage, n_distinctive_unseen).

        coverage = share of the query's IDF mass found in the chunk. Unseen *generic* words are
        ignored; unseen *distinctive* words keep maximum weight and are counted so the caller
        can apply a stricter threshold (the question mentions something the docs never mention).
        """
        have = set(chunk.toks)
        total = got = 0.0
        unseen_distinctive = 0
        for t in set(tokens(query)):
            seen = t in self.df
            if not seen and t in COMMON_STEMS:
                continue
            w = self.idf(t)
            total += w
            if t in have:
                got += w
            if not seen:
                unseen_distinctive += 1
        return (got / total if total else 0.0), unseen_distinctive
