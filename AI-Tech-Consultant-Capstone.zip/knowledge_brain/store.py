"""SQLite persistence for escalations and documentation-update history."""
import sqlite3, threading, time, json
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS escalations(
  id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL, question TEXT, contact TEXT,
  reason TEXT, status TEXT DEFAULT 'open', notes TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS updates(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, source TEXT, summary TEXT);
"""


class Store:
    def __init__(self, path: str | Path = ":memory:"):
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.db.executescript(SCHEMA); self.db.commit()

    def add_escalation(self, question, contact="", reason="") -> int:
        with self.lock:
            cur = self.db.execute("INSERT INTO escalations(created,question,contact,reason) VALUES(?,?,?,?)",
                                  (time.time(), question, contact, reason))
            self.db.commit(); return cur.lastrowid

    def list_escalations(self, status=None):
        with self.lock:
            q = "SELECT * FROM escalations" + (" WHERE status=?" if status else "") + " ORDER BY id"
            return [dict(r) for r in self.db.execute(q, (status,) if status else ())]

    def resolve_escalation(self, id, notes=""):
        with self.lock:
            self.db.execute("UPDATE escalations SET status='resolved', notes=? WHERE id=?", (notes, id))
            self.db.commit()

    def log_update(self, source, summary: dict):
        with self.lock:
            self.db.execute("INSERT INTO updates(ts,source,summary) VALUES(?,?,?)",
                            (time.time(), source, json.dumps(summary)))
            self.db.commit()

    def list_updates(self):
        with self.lock:
            return [dict(r) | {"summary": json.loads(r["summary"])}
                    for r in self.db.execute("SELECT * FROM updates ORDER BY id")]
