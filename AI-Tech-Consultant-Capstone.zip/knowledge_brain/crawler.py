"""Documentation ingestion.

Sources, in order (BRAIN_SOURCE=auto):
  1. live   - crawl BRAIN_SITEMAP_URL (real Brilliant Directories Solution Center)
  2. cache  - last successful live crawl stored in data/crawl/pages.json
  3. fallback - local SYNTHETIC docs in data/fallback_docs (NOT real BD documentation)

The pure parsing functions (parse_sitemap, extract_page) are unit-tested on mock
input. The live network path itself has NOT been exercised against the real site
from the build sandbox (DNS was blocked) - see README "Known limitations".
"""
from __future__ import annotations
import hashlib, json, os, re, time
from dataclasses import dataclass, asdict
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
SITEMAP_URL = os.getenv("BRAIN_SITEMAP_URL", "https://support.brilliantdirectories.com/support/sitemap.xml")


@dataclass
class Document:
    url: str
    title: str
    text: str
    lastmod: str = ""

    @property
    def hash(self) -> str:
        return hashlib.sha256((self.title + "\n" + self.text).encode()).hexdigest()[:16]


def parse_sitemap(xml: str) -> tuple[list[tuple[str, str]], list[str]]:
    """Return (page_urls_with_lastmod, child_sitemap_urls)."""
    pages, children = [], []
    for block in re.findall(r"<(url|sitemap)>(.*?)</\1>", xml, flags=re.S | re.I):
        kind, body = block
        loc = re.search(r"<loc>\s*(.*?)\s*</loc>", body, flags=re.S | re.I)
        if not loc:
            continue
        lm = re.search(r"<lastmod>\s*(.*?)\s*</lastmod>", body, flags=re.S | re.I)
        if kind.lower() == "sitemap":
            children.append(loc.group(1))
        else:
            pages.append((loc.group(1), lm.group(1) if lm else ""))
    return pages, children


def extract_page(html: str, url: str, lastmod: str = "") -> Document | None:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "header", "footer", "aside", "form", "noscript"]):
        tag.decompose()
    h1 = soup.find("h1")
    title = (h1.get_text(" ", strip=True) if h1 else "") or (soup.title.get_text(strip=True) if soup.title else "")
    main = soup.find("article") or soup.find("main") or soup.find(id="content") or soup.body or soup
    paras = [p.get_text(" ", strip=True) for p in main.find_all(["p", "li", "h2", "h3", "h4"])]
    text = "\n\n".join(p for p in paras if p)
    if len(text) < 80 or not title:
        return None
    return Document(url=url, title=title, text=text, lastmod=lastmod)


def crawl_live(sitemap_url: str = SITEMAP_URL, max_pages: int | None = None, delay: float = 0.2,
               session=None) -> list[Document]:
    import requests
    session = session or requests.Session()
    session.headers.update({"User-Agent": "capstone-knowledge-brain/1.0 (educational project)"})
    max_pages = max_pages or int(os.getenv("BRAIN_MAX_PAGES", "300"))
    queue, seen_maps, page_urls = [sitemap_url], set(), []
    while queue:
        sm = queue.pop(0)
        if sm in seen_maps:
            continue
        seen_maps.add(sm)
        r = session.get(sm, timeout=20)
        r.raise_for_status()
        pages, children = parse_sitemap(r.text)
        page_urls += pages
        queue += children
    docs: list[Document] = []
    for url, lastmod in page_urls[:max_pages]:
        try:
            r = session.get(url, timeout=20)
            if r.status_code != 200:
                continue
            d = extract_page(r.text, url, lastmod)
            if d:
                docs.append(d)
        except Exception:
            continue
        time.sleep(delay)
    if not docs:
        raise RuntimeError("live crawl produced no documents")
    return docs


def load_fallback(path: Path | None = None) -> list[Document]:
    path = path or DATA_DIR / "fallback_docs"
    docs = []
    for f in sorted(Path(path).glob("*.md")):
        raw = f.read_text(encoding="utf-8")
        head, _, body = raw.partition("\n\n")
        meta = dict(line.split(": ", 1) for line in head.splitlines() if ": " in line)
        docs.append(Document(url=meta.get("url", f"local://fallback/{f.stem}"),
                             title=meta.get("title", f.stem), text=body.strip()))
    return docs


def save_cache(docs: list[Document], path: Path | None = None) -> None:
    path = path or DATA_DIR / "crawl" / "pages.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([asdict(d) for d in docs], indent=1))


def load_cache(path: Path | None = None) -> list[Document]:
    path = path or DATA_DIR / "crawl" / "pages.json"
    if not path.exists():
        return []
    return [Document(**d) for d in json.loads(path.read_text())]


def load_documents(mode: str | None = None, fallback_dir: Path | None = None) -> tuple[list[Document], str]:
    """Return (documents, source_label). Never silently pretends fallback is live."""
    mode = (mode or os.getenv("BRAIN_SOURCE", "auto")).lower()
    if mode == "fallback":
        return load_fallback(fallback_dir), "fallback"
    if mode in ("live", "auto"):
        try:
            docs = crawl_live()
            save_cache(docs)
            return docs, "live"
        except Exception as e:  # network blocked, site down, etc.
            if mode == "live":
                raise
            cached = load_cache()
            if cached:
                return cached, "cache"
            print(f"[brain] live crawl unavailable ({type(e).__name__}); using local SYNTHETIC fallback docs")
            return load_fallback(fallback_dir), "fallback"
    raise ValueError(f"unknown BRAIN_SOURCE {mode!r}")
