"""Tiny text helpers (tokenizing + a crude stemmer). No external NLP deps."""
import re

STOP = set("""a an the is are was were be been to of in on for and or with how do does did i you we can my me
it this that what when where which who why should would could will at by from as if so not no your our have has had
about into than then there their they them its im its please need want get make use using""".split())


def stem(t: str) -> str:
    if t.endswith("s") and not t.endswith("ss") and len(t) > 3:
        t = t[:-1]
    if t.endswith("ing") and len(t) > 5:
        t = t[:-3]
    elif t.endswith("ed") and len(t) > 4:
        t = t[:-2]
    return t


def tokens(text: str, keep_stop: bool = False) -> list[str]:
    toks = re.findall(r"[a-z0-9]+", text.lower())
    return [stem(t) for t in toks if keep_stop or t not in STOP]


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", text).strip())
    return [p for p in parts if p]


# Generic English / support-chatter words. If one of these is NOT in the docs we ignore it
# (it is filler, not evidence of an unanswerable topic). Distinctive unseen words
# (e.g. "kubernetes", "mobile", "quickbooks") are NOT in this list and trigger a stricter gate.
COMMON_WORDS = set("""
offer offers long take taking going go goes gone customer customers middle file format show shows separate each rank
way ways work works working worked change changes give gives let lets sign wait waiting without before after during
run running big small large new old first last next time day days week month year people person thing things something
anything everything start started stop open close help know need want try tried find found see look looking check keep
stay turn move put set add remove update create made makes problem issue question answer reason happen happens mean
means able ability possible really very just also still even much many more most less least other another same
different good bad best better right wrong sure ok okay hello hi thanks thank yes today tomorrow yesterday now soon
always never often sometimes already again here anyone someone everyone platform system software tool option options
feature features available allow allowed allows enable enabled disable disabled number list homepage home site website
place part type kind sort lot bit little able own self let does done doing being getting put
""".split())
COMMON_STEMS = {stem(w) for w in COMMON_WORDS}
