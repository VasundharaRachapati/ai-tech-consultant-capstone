"""HTTP API for the Knowledge Brain.   Run:  uvicorn knowledge_brain.api:app --port 8000"""
from __future__ import annotations
import os
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .brain import KnowledgeBrain

try:
    from dotenv import load_dotenv; load_dotenv()
except Exception:
    pass


class AskIn(BaseModel):
    question: str


class EscalateIn(BaseModel):
    question: str
    contact: str = ""
    reason: str = "user confirmed"


class ResolveIn(BaseModel):
    notes: str = ""


def create_app(brain: KnowledgeBrain) -> FastAPI:
    app = FastAPI(title="Knowledge Brain API", version="1.0")

    @app.get("/health")
    def health():
        return {"ok": True, "corpus_source": brain.source, "documents": len(brain.docs),
                "answer_mode": "llm" if brain.use_llm else "extractive"}

    @app.post("/ask")
    def ask(body: AskIn):
        return brain.ask(body.question)

    @app.post("/escalate")
    def escalate(body: EscalateIn):
        return brain.escalate(body.question, body.contact, body.reason)

    @app.get("/escalations")
    def escalations(status: str | None = None):
        return brain.store.list_escalations(status)

    @app.post("/escalations/{eid}/resolve")
    def resolve(eid: int, body: ResolveIn):
        brain.store.resolve_escalation(eid, body.notes)
        return {"ok": True}

    @app.post("/refresh")
    def refresh():
        return brain.refresh()

    @app.get("/updates")
    def updates():
        return brain.store.list_updates()

    @app.get("/sources")
    def sources():
        return [{"url": d.url, "title": d.title, "hash": d.hash} for d in brain.docs.values()]

    return app


def _default_app() -> FastAPI:
    db = Path(__file__).resolve().parent.parent / "data" / "brain.db"
    return create_app(KnowledgeBrain(db_path=db).load())


def __getattr__(name):           # lazy: `uvicorn knowledge_brain.api:app` builds it on first access
    if name == "app":
        global app
        app = _default_app()
        return app
    raise AttributeError(name)
