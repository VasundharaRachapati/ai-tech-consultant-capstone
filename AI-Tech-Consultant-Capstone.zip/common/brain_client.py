"""Thin client used by Task 2 and Task 3 to call the Knowledge Brain API over HTTP."""
import os
import httpx


class BrainUnavailable(RuntimeError):
    pass


class BrainClient:
    def __init__(self, base_url: str | None = None, client=None, timeout: float = 15.0):
        # `client` lets tests inject a FastAPI TestClient (same HTTP interface, no network).
        self.client = client or httpx.Client(
            base_url=base_url or os.getenv("BRAIN_API_URL", "http://127.0.0.1:8000"), timeout=timeout)

    def _call(self, method, path, **kw):
        try:
            r = getattr(self.client, method)(path, **kw)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            raise BrainUnavailable(f"Knowledge Brain API call {path} failed: {e}") from e

    def ask(self, question: str) -> dict:
        return self._call("post", "/ask", json={"question": question})

    def escalate(self, question: str, contact: str = "", reason: str = "") -> dict:
        return self._call("post", "/escalate", json={"question": question, "contact": contact, "reason": reason})

    def health(self) -> dict:
        return self._call("get", "/health")
