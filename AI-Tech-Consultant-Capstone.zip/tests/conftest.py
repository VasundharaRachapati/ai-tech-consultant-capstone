import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import pytest
from fastapi.testclient import TestClient
from knowledge_brain.brain import KnowledgeBrain
from knowledge_brain.api import create_app
from common.brain_client import BrainClient


@pytest.fixture(scope="session")
def brain():
    return KnowledgeBrain(source_mode="fallback", use_llm=False).load()


@pytest.fixture()
def api(brain):
    return TestClient(create_app(brain))


@pytest.fixture()
def client(api):
    return BrainClient(client=api)


class FakeBrain:
    """Deterministic stand-in for the Brain API used to unit-test policy logic."""
    def __init__(self, status="answered", confidence=0.9):
        self.status, self.confidence, self.tickets = status, confidence, 0

    def ask(self, q):
        if self.status == "answered":
            return {"status": "answered", "confidence": self.confidence, "answer": "Do the documented thing. [1]",
                    "citations": [{"n": 1, "title": "Doc", "url": "local://fallback/doc"}]}
        return {"status": self.status, "confidence": 0.1, "answer": "unknown", "citations": []}

    def escalate(self, q, contact="", reason=""):
        self.tickets += 1
        return {"ticket_id": self.tickets, "status": "open"}
