import json
from pathlib import Path
import pytest
from common.brain_client import BrainUnavailable
from inbox_agent import agent as A
from inbox_agent.agent import InboxAgent
from inbox_agent.classifier import classify
from inbox_agent import simulate, rules as R
from tests.conftest import FakeBrain

ROOT = Path(__file__).resolve().parent.parent
EMAILS = json.loads((ROOT / "samples" / "emails.json").read_text())


def mail(i, text="How do I connect Stripe?", name="Priya Nair", cat="how_to"):
    return {"id": f"T{i:03d}", "from": "a@b.c", "name": name, "subject": text[:30], "text": text,
            "body": f"Hi,\n\n{text}\n\nThanks", "true_category": cat}


def feed_unchanged(ag, n, start=0):
    for i in range(start, start + n):
        r = ag.process(mail(i)); assert r["decision"] == "needs_review"; ag.review(r["email_id"])


def test_sample_set_size_and_labels():
    assert len(EMAILS) >= 50 and len({e["id"] for e in EMAILS}) == len(EMAILS)
    assert {e["true_category"] for e in EMAILS} >= {"how_to", "billing", "bug_report", "feature_request", "cancellation", "complaint", "sales_inquiry", "spam"}


@pytest.mark.parametrize("e", EMAILS, ids=lambda e: e["id"])
def test_classifier_on_synthetic_set(e):
    assert classify(e["subject"] + ". " + e["text"])[0] == e["true_category"]


def test_19_unchanged_not_enough_20th_enables():
    ag = InboxAgent(FakeBrain())
    feed_unchanged(ag, 19)
    assert ag.state("how_to")["auto_enabled"] == 0 and ag.state("how_to")["streak"] == 19
    r = ag.process(mail(19)); out = ag.review(r["email_id"])
    assert out["event"] == "auto_send_enabled" and ag.state("how_to")["auto_enabled"] == 1


def test_edit_resets_streak():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 12)
    r = ag.process(mail(99)); ag.review(r["email_id"], r["draft"] + "\n\nP.S. edited")
    assert ag.state("how_to")["streak"] == 0


def test_after_enable_eligible_drafts_are_auto_sent():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    r = ag.process(mail(50)); assert r["decision"] == "auto_sent"
    assert ag.db.execute("SELECT sent FROM mails WHERE email_id='T050'").fetchone()[0] == 1


def test_autosend_is_per_category():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    assert ag.process(mail(60, "Please add a dark mode feature request", cat="feature_request"))["decision"] == "needs_review"


def test_low_confidence_not_auto_sent_even_when_enabled():
    brain = FakeBrain(); ag = InboxAgent(brain); feed_unchanged(ag, 20)
    brain.confidence = 0.3
    r = ag.process(mail(70)); assert r["decision"] == "needs_review" and r["eligible"] is False


def test_unknown_answers_never_count_and_open_ticket():
    brain = FakeBrain("unknown"); ag = InboxAgent(brain)
    for i in range(25):
        r = ag.process(mail(i)); assert r["eligible"] is False
        ag.review(r["email_id"])
    assert ag.state("how_to")["streak"] == 0 and ag.state("how_to")["auto_enabled"] == 0
    assert brain.tickets == 25 and "ticket #" in r["draft"] and "don't want to guess" in r["draft"]


@pytest.mark.parametrize("cat,text", [("billing", "I was charged twice, check my invoice."),
                                      ("cancellation", "Please cancel my subscription."),
                                      ("complaint", "This is unacceptable and terrible.")])
def test_sensitive_categories_never_auto_send(cat, text):
    ag = InboxAgent(FakeBrain())
    for i in range(30):
        r = ag.process(mail(i, text, cat=cat)); assert r["category"] == cat and r["decision"] == "needs_review"
        ag.review(r["email_id"])
    assert ag.state(cat)["auto_enabled"] == 0


def test_spam_archived_without_draft():
    r = InboxAgent(FakeBrain()).process(mail(1, "CONGRATULATIONS winner! Click here for crypto", cat="spam"))
    assert r["decision"] == "archived_spam" and r["draft"] == ""


def test_learns_signoff_and_applies_to_next_draft():
    ag = InboxAgent(FakeBrain()); r = ag.process(mail(1))
    edited = r["draft"].replace("Best regards,\nSupport Team", "Warm regards,\nAlex"); ag.review("T001", edited)
    assert "Warm regards,\nAlex" in ag.process(mail(2))["draft"]


def test_learns_greeting_with_name_placeholder():
    ag = InboxAgent(FakeBrain()); r = ag.process(mail(1, name="Priya Nair"))
    ag.review("T001", r["draft"].replace("Hi Priya,", "Hello Priya,"))
    assert ag.process(mail(2, name="Tom Becker"))["draft"].startswith("Hello Tom,")


def test_learns_to_suppress_deleted_boilerplate():
    ag = InboxAgent(FakeBrain()); r = ag.process(mail(1))
    ag.review("T001", r["draft"].replace("Let us know if you have any other questions.\n", ""))
    assert "Let us know" not in ag.process(mail(2))["draft"]


def test_learn_function_direct():
    rules = R.new_rules()
    out = R.learn("Hi Sam,\n\nBody line here.\n\nBest regards,\nSupport Team", "Hi Sam,\n\nBody line here.\nExtra note.\n\nCheers,\nAl", "Sam", rules)
    assert rules["signoff"] == "Cheers,\nAl" and "Extra note." in rules["add"] and out


def test_one_bad_outcome_does_not_suspend_two_do():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    ids = [ag.process(mail(100 + i))["email_id"] for i in range(5)]
    assert ag.report_outcome(ids[0], False)["suspended"] is False
    assert ag.report_outcome(ids[1], True)["suspended"] is False
    res = ag.report_outcome(ids[2], False)
    assert res["suspended"] is True and ag.state("how_to")["auto_enabled"] == 0 and ag.state("how_to")["suspended"] == 1


def test_suspension_resets_streak_and_requires_review_again():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    a, b = ag.process(mail(100))["email_id"], ag.process(mail(101))["email_id"]
    ag.report_outcome(a, False); ag.report_outcome(b, False)
    r = ag.process(mail(102)); assert r["decision"] == "needs_review"
    assert ag.state("how_to")["streak"] == 0


def test_rollback_discards_rules_learned_after_enable():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    a, b = ag.process(mail(100)), ag.process(mail(101))
    ag.audit(a["email_id"], a["draft"].rsplit("\n\n", 1)[0] + "\n\nCheers!")      # learns a bad signoff + bad outcome
    assert ag.state("how_to")["rules"]["signoff"] == "Cheers!"
    ag.report_outcome(b["email_id"], False)                                      # second bad -> suspend + rollback
    assert ag.state("how_to")["rules"]["signoff"] is None
    assert any(e["kind"] == "auto_send_suspended_rolled_back" for e in ag.events())


def test_autosend_can_be_re_earned_after_suspension():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    a, b = ag.process(mail(100))["email_id"], ag.process(mail(101))["email_id"]
    ag.report_outcome(a, False); ag.report_outcome(b, False)
    feed_unchanged(ag, 20, start=200)
    assert ag.state("how_to")["auto_enabled"] == 1 and ag.state("how_to")["suspended"] == 0
    assert ag.process(mail(300))["decision"] == "auto_sent"


def test_old_bad_outcomes_from_previous_epoch_do_not_retrigger():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    a, b = ag.process(mail(100))["email_id"], ag.process(mail(101))["email_id"]
    ag.report_outcome(a, False); ag.report_outcome(b, False)
    feed_unchanged(ag, 20, start=200)
    c = ag.process(mail(300))["email_id"]
    assert ag.report_outcome(c, False)["suspended"] is False        # only 1 bad in the NEW epoch


def test_brain_down_produces_safe_holding_draft():
    class Down:
        def ask(self, q): raise BrainUnavailable("down")
        def escalate(self, *a, **k): raise BrainUnavailable("down")
    r = InboxAgent(Down()).process(mail(1))
    assert r["decision"] == "needs_review" and r["eligible"] is False and "personally" in r["draft"]


def test_cannot_review_twice_or_review_autosent():
    ag = InboxAgent(FakeBrain()); feed_unchanged(ag, 20)
    with pytest.raises(ValueError): ag.review("T000")
    auto = ag.process(mail(500))["email_id"]
    with pytest.raises(ValueError): ag.review(auto)


def test_end_to_end_simulation_with_real_brain(client):
    ag = InboxAgent(client)
    res = simulate.run(ag, EMAILS)
    kinds = [e["kind"] for e in res["events"]]
    assert "auto_send_enabled" in kinds and "auto_send_suspended_rolled_back" in kinds and "edit_learned" in kinds
    assert len(res["log"]) == len(EMAILS) >= 50
    assert any(x["decision"] == "auto_sent" for x in res["log"]) and any(x["decision"] == "archived_spam" for x in res["log"])
