import json, re
from pathlib import Path
import pytest
from common.brain_client import BrainClient, BrainUnavailable
from sow_agent import pipeline
from sow_agent.extract import extract, parse_meeting, load_meetings

ROOT = Path(__file__).resolve().parent.parent
MEET = ROOT / "samples" / "meetings"
CASES = json.loads((ROOT / "evals" / "cases_sow.json").read_text())


def mini(text, date="2026-01-01"):
    return parse_meeting(f"Meeting: M\nDate: {date}\nType: meeting\nAttendees: Dana Whitfield (Client), Sam Patel (Consultant)\n\nDana: {text}\n")


@pytest.mark.parametrize("c", CASES, ids=lambda c: c["id"])
def test_requirement_extraction_cases(c):
    ex = extract([mini(c["text"])])
    if c["expect"] == "none":
        assert not ex["requirements"] and not ex["dropped"] and not ex["constraints"]
    elif c["expect"] == "constraint":
        assert ex["constraints"] and not ex["requirements"]
    elif c["expect"] == "drop":
        assert ex["dropped"] and set(ex["dropped"][0]["features"]) == set(c["features"]) and not ex["requirements"]
    else:
        assert len(ex["requirements"]) == 1
        r = ex["requirements"][0]
        assert r["kind"] == c["expect"] or (c["expect"] == "unmapped" and r["kind"] == "unmapped")
        assert set(c["features"]) <= set(r["features"])


def test_consultant_statements_are_ignored():
    m = parse_meeting("Meeting: M\nDate: 2026-01-01\nAttendees: Dana W (Client), Sam P (Consultant)\n\nSam: We need a mobile app for sure.\n")
    assert extract([m])["requirements"] == []


def test_later_meeting_overrides_constraint_and_history_logged():
    a = mini("Our budget is around $18,000.", "2026-01-01"); b = mini("The budget is now $16,000.", "2026-02-01")
    ex = extract([b, a])                      # order of input must not matter (sorted by date)
    assert ex["constraints"]["budget"] == 16000 and ex["history"][0]["from"] == 18000


@pytest.fixture()
def built(client):
    return pipeline.build_sow(load_meetings(MEET), client)


def test_sample_inputs_meet_brief():
    ms = load_meetings(MEET)
    assert sum(m["type"] == "meeting" for m in ms) >= 3 and sum(m["type"] == "follow_up" for m in ms) >= 1


def test_expected_scope_split(built):
    ins = {i["id"] for i in built["in_scope"]}; outs = {o["id"] for o in built["out_of_scope"]}
    assert {"membership_plans", "csv_import", "payments", "lead_routing", "staff_roles", "webhooks_crm"} <= ins
    assert outs == {"native_mobile_app", "erp_integration", "whatsapp_chatbot"}


def test_followup_drop_removes_reviews(built):
    assert "reviews" not in {i["id"] for i in built["in_scope"]}
    assert any(d["feature"] == "reviews" for d in built["dropped"])
    assert not any(t["feature"] == "reviews" for t in built["tasks"])


def test_constraints_updated_by_followup(built):
    assert built["constraints"] == {"budget": 16000, "deadline": "February 28"} and len(built["constraint_changes"]) == 2


def test_unmapped_requests_flagged_not_estimated(built):
    texts = " ".join(n["text"] for n in built["needs_clarification"])
    assert "waitlist" in texts and "Excel" in texts
    assert any("waitlist" in o for o in built["open_items_for_human"])


def test_in_scope_items_verified_via_brain_with_citations(built):
    for i in built["in_scope"]:
        assert i["verified_in_docs"] and i["docs_evidence"]["citations"]


def test_out_of_scope_items_have_brain_evidence_and_reason(built):
    for o in built["out_of_scope"]:
        assert o["docs_evidence"]["status"] == "unknown" and o["reason"] and "no documentation" in o["note"]


def test_hours_arithmetic_consistent(built):
    t = built["totals"]; total = sum(x["hours"] for x in built["tasks"])
    assert abs(total - t["subtotal_hours"]) < 0.11
    assert abs(t["subtotal_hours"] + t["contingency_hours"] - t["total_hours"]) < 0.11
    assert t["estimated_cost"] == round(t["total_hours"] * t["hourly_rate_assumed"])
    assert all(x["hours"] > 0 for x in built["tasks"])


def test_budget_overrun_is_flagged(client):
    ms = load_meetings(MEET)
    for m in ms:
        if m["type"] == "follow_up":
            m["turns"] = [(s, r, t.replace("$16,000", "$5,000")) for s, r, t in m["turns"]]
    sow = pipeline.build_sow(ms, client)
    assert sow["totals"]["within_budget"] is False and any("EXCEEDS" in o for o in sow["open_items_for_human"])


def test_brain_unavailable_flags_everything_for_human():
    class Down:
        def ask(self, q): raise BrainUnavailable("down")
    sow = pipeline.build_sow(load_meetings(MEET), Down())
    assert all(not i["verified_in_docs"] for i in sow["in_scope"])
    assert len(sow["open_items_for_human"]) >= len(sow["in_scope"])


def test_draft_proposal_is_watermarked_and_lists_sections(built, tmp_path):
    pipeline.write_outputs(built, tmp_path)
    md = (tmp_path / "proposal_DRAFT.md").read_text()
    assert "DRAFT - NOT APPROVED" in md and "## 3. Out of scope" in md and "## 6. Tasks and estimated hours" in md
    assert (tmp_path / "tasks.csv").read_text().startswith("feature,task,hours")


def test_finalize_refused_without_approval(built, tmp_path):
    pipeline.write_outputs(built, tmp_path)
    with pytest.raises(pipeline.ApprovalRequired): pipeline.finalize(tmp_path)
    assert not (tmp_path / "proposal_FINAL.md").exists()


def test_approval_requires_acknowledging_open_items(built, tmp_path):
    pipeline.write_outputs(built, tmp_path)
    with pytest.raises(pipeline.ApprovalRequired): pipeline.approve(tmp_path, "Jo Reviewer")
    with pytest.raises(ValueError): pipeline.approve(tmp_path, "  ", True)


def test_finalize_after_approval_stamps_approver(built, tmp_path):
    pipeline.write_outputs(built, tmp_path); pipeline.approve(tmp_path, "Jo Reviewer", True)
    p = pipeline.finalize(tmp_path)
    assert "APPROVED** by Jo Reviewer" in p.read_text() and "DRAFT - NOT APPROVED" not in p.read_text()


def test_edit_after_approval_invalidates_it(built, tmp_path):
    pipeline.write_outputs(built, tmp_path); pipeline.approve(tmp_path, "Jo Reviewer", True)
    sow = json.loads((tmp_path / "sow.json").read_text()); sow["tasks"][0]["hours"] += 10
    (tmp_path / "sow.json").write_text(json.dumps(sow))
    with pytest.raises(pipeline.ApprovalRequired, match="changed after approval"): pipeline.finalize(tmp_path)


def test_cli_finalize_exit_code_when_unapproved(tmp_path, built):
    from sow_agent import cli
    pipeline.write_outputs(built, tmp_path)
    with pytest.raises(SystemExit) as e: cli.main(["finalize", "--out", str(tmp_path)])
    assert e.value.code == 2


def test_pipeline_run_end_to_end(client, tmp_path):
    r = pipeline.run(MEET, tmp_path, client)
    assert r["sow"]["status"] == "DRAFT_PENDING_HUMAN_APPROVAL" and (tmp_path / "sow.json").exists()
