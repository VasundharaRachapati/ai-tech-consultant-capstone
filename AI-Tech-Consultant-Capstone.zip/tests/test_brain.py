import json, shutil
from pathlib import Path
import pytest
from knowledge_brain import crawler
from knowledge_brain.brain import KnowledgeBrain

EV = Path(__file__).resolve().parent.parent / "evals"
MAIN = json.loads((EV / "cases_brain.json").read_text())
HELD = json.loads((EV / "cases_brain_heldout.json").read_text())
ALL = MAIN + HELD
# Documented false-"unknown" misses (over-cautious). strict xfail: if one starts passing, the test tells us.
KNOWN_MISSES = {"B02", "B10", "B13", "V01"}

answerable = [c for c in ALL if c["expect"] == "answered"]
unknown = [c for c in ALL if c["expect"] == "unknown"]
human = [c for c in ALL if c["expect"] in ("escalation_requested", "not_escalation")]


@pytest.mark.parametrize("c", [pytest.param(c, marks=pytest.mark.xfail(strict=True, reason="known over-cautious miss"))
                               if c["id"] in KNOWN_MISSES else c for c in answerable], ids=lambda c: c["id"])
def test_answerable_gets_cited_answer(brain, c):
    r = brain.ask(c["q"])
    assert r["status"] == "answered"
    assert r["citations"] and all(x["url"] and x["title"] for x in r["citations"])
    assert any(x["url"].rsplit("/", 1)[-1] in c["any_of"] for x in r["citations"])
    assert "[1]" in r["answer"]


@pytest.mark.parametrize("c", unknown, ids=lambda c: c["id"])
def test_unknown_is_honest_no_fabricated_citations(brain, c):
    r = brain.ask(c["q"])
    assert r["status"] == "unknown" and r["citations"] == []
    assert "don't want to guess" in r["answer"] and r["escalation"]["offered"] is True


@pytest.mark.parametrize("c", human, ids=lambda c: c["id"])
def test_human_escalation_intent(brain, c):
    r = brain.ask(c["q"])
    if c["expect"] == "escalation_requested":
        assert r["status"] == "escalation_requested" and r["escalation"]["ticket_id"]
    else:
        assert r["status"] != "escalation_requested"


def test_empty_question(brain):
    assert brain.ask("   ")["status"] == "unknown"


def test_api_health_and_ask(api):
    assert api.get("/health").json()["documents"] == 17
    r = api.post("/ask", json={"question": "How do I import members from a CSV file?"}).json()
    assert r["status"] == "answered" and r["corpus_source"] == "fallback"


def test_api_escalation_lifecycle(api):
    t = api.post("/escalate", json={"question": "Billing oddity", "contact": "a@b.com"}).json()
    assert t["status"] == "open"
    assert any(e["id"] == t["ticket_id"] for e in api.get("/escalations", params={"status": "open"}).json())
    api.post(f"/escalations/{t['ticket_id']}/resolve", json={"notes": "done"})
    assert all(e["id"] != t["ticket_id"] for e in api.get("/escalations", params={"status": "open"}).json())


def test_api_sources_listing(api):
    s = api.get("/sources").json()
    assert len(s) == 17 and all(x["url"].startswith("local://fallback/") for x in s)


def test_refresh_detects_added_changed_removed(tmp_path):
    d = tmp_path / "docs"; shutil.copytree(crawler.DATA_DIR / "fallback_docs", d)
    b = KnowledgeBrain(source_mode="fallback", fallback_dir=d, use_llm=False).load()
    assert b.refresh()["reindexed"] is False                       # nothing changed
    (d / "backups-and-restore.md").write_text("title: Backups and Restore\nurl: local://fallback/backups-and-restore\n\nBackups now run every hour and are kept for 90 days.")
    (d / "new-doc.md").write_text("title: Dark Mode\nurl: local://fallback/new-doc\n\nThe admin panel supports a dark mode theme that you can enable in Appearance settings for all staff.")
    (d / "widgets-and-modules.md").unlink()
    diff = b.refresh()
    assert diff["changed"] == ["local://fallback/backups-and-restore"]
    assert diff["added"] == ["local://fallback/new-doc"] and diff["removed"] == ["local://fallback/widgets-and-modules"]
    assert b.ask("Does the admin panel have a dark mode theme?")["status"] == "answered"   # new knowledge live
    assert b.ask("How do I add a testimonial slider widget?")["status"] == "unknown"       # removed knowledge gone
    assert "90 days" in b.ask("How long are backups kept?")["answer"]                      # changed content served
    assert len(b.store.list_updates()) == 2


def test_sitemap_parsing_urlset_and_index():
    xml = "<urlset><url><loc>https://x/a</loc><lastmod>2026-01-01</lastmod></url><url><loc>https://x/b</loc></url></urlset>"
    pages, kids = crawler.parse_sitemap(xml)
    assert pages == [("https://x/a", "2026-01-01"), ("https://x/b", "")] and kids == []
    pages, kids = crawler.parse_sitemap("<sitemapindex><sitemap><loc>https://x/s2.xml</loc></sitemap></sitemapindex>")
    assert pages == [] and kids == ["https://x/s2.xml"]


def test_extract_page_strips_boilerplate_and_skips_thin_pages():
    html = ("<html><head><title>T</title></head><body><nav>menu menu</nav><article><h1>Reset a password</h1>"
            "<p>Open the login page and choose Forgot password. An email with a reset link is sent to the member.</p>"
            "<p>The link expires after one hour so request a new one if needed.</p></article><footer>copyright</footer></body></html>")
    d = crawler.extract_page(html, "https://x/p")
    assert d.title == "Reset a password" and "menu" not in d.text and "copyright" not in d.text
    assert crawler.extract_page("<html><body><h1>Hi</h1><p>short</p></body></html>", "https://x/q") is None


def test_crawl_live_with_fake_session():
    class R:
        def __init__(s, text, code=200): s.text, s.status_code = text, code
        def raise_for_status(s): pass
    page = "<article><h1>Doc {n}</h1><p>" + "Useful documentation sentence about the platform. " * 5 + "</p></article>"
    class S:
        headers = {}
        def get(self, url, timeout=0):
            if url.endswith("sitemap.xml"):
                return R("<urlset><url><loc>https://x/1</loc></url><url><loc>https://x/2</loc></url></urlset>")
            return R(page.format(n=url[-1]))
    docs = crawler.crawl_live("https://x/sitemap.xml", delay=0, session=S())
    assert [d.title for d in docs] == ["Doc 1", "Doc 2"]


def test_auto_mode_falls_back_when_live_fails(monkeypatch, tmp_path):
    monkeypatch.setattr(crawler, "crawl_live", lambda *a, **k: (_ for _ in ()).throw(ConnectionError("blocked")))
    monkeypatch.setattr(crawler, "DATA_DIR", tmp_path)          # no cache present
    docs, label = crawler.load_documents("auto", Path(__file__).resolve().parent.parent / "data" / "fallback_docs")
    assert label == "fallback" and len(docs) == 17


def test_live_mode_raises_instead_of_pretending(monkeypatch):
    monkeypatch.setattr(crawler, "crawl_live", lambda *a, **k: (_ for _ in ()).throw(ConnectionError("blocked")))
    with pytest.raises(ConnectionError):
        crawler.load_documents("live")


def test_llm_mode_used_when_available_and_falls_back_on_error(monkeypatch):
    b = KnowledgeBrain(source_mode="fallback", use_llm=True).load()
    monkeypatch.setattr(b, "_llm_answer", lambda q, ch: "LLM says: connect Stripe keys [1]")
    r = b.ask("How do I connect Stripe for payments?")
    assert r["answer_mode"] == "llm" and r["citations"]
    monkeypatch.setattr(b, "_llm_answer", lambda q, ch: (_ for _ in ()).throw(RuntimeError("api down")))
    assert b.ask("How do I connect Stripe for payments?")["answer_mode"] == "extractive"
