"""SIMULATED human reviewer + customer feedback, used by the demo and evals.

!! Everything here is scripted, not real human behaviour. It exists to exercise the learning and
!! auto-send machinery deterministically. Real reviewers are noisier.
"""
from __future__ import annotations
import json
from pathlib import Path
from . import rules as R

PREF_SIGNOFF = "Warm regards,\nAlex from Support"
PREF_GREETING_LATER = "Hello {first},"
UNWANTED = "Let us know if you have any other questions."
GREETING_CHANGE_AT_ELIGIBLE_REVIEW = 4       # reviewer changes their mind on greeting at this eligible review
BAD_AUTOSENT = {3: "customer_reply", 4: "audit_edit"}   # nth auto-sent how_to email -> kind of bad signal


def ideal_version(draft: str, first: str, greeting_pref: str | None) -> str:
    blocks = [b for b in draft.strip().split("\n\n")]
    if greeting_pref:
        blocks[0] = greeting_pref.replace("{first}", first)
    blocks[-1] = PREF_SIGNOFF
    text = "\n\n".join(blocks)
    return "\n".join(l for l in text.split("\n") if l.strip() != UNWANTED)


def run(agent, emails: list[dict], out_dir: Path | None = None) -> dict:
    log, eligible_reviews, auto_n, greeting_pref = [], 0, 0, None
    for em in emails:
        res = agent.process(em)
        first = em["name"].split()[0]
        row = {"email_id": em["id"], "true": em["true_category"], "category": res["category"],
               "decision": res["decision"], "brain_status": res.get("brain_status"),
               "confidence": res.get("confidence"), "eligible": res.get("eligible")}
        if res["decision"] == "needs_review":
            if res.get("eligible"):
                eligible_reviews += 1
                if eligible_reviews == GREETING_CHANGE_AT_ELIGIBLE_REVIEW:
                    greeting_pref = PREF_GREETING_LATER
            ideal = ideal_version(res["draft"], first, greeting_pref)
            out = agent.review(em["id"], None if ideal.split() == res["draft"].split() else ideal)
            row |= {"human": "approved_unchanged" if out["unchanged"] else "edited", "streak_after": out["streak"],
                    "learned": out["learned"], "event": out["event"]}
        elif res["decision"] == "auto_sent":
            auto_n += 1
            kind = BAD_AUTOSENT.get(auto_n)
            if kind == "customer_reply":
                row["quality"] = agent.report_outcome(em["id"], good=False)
            elif kind == "audit_edit":
                bad_text = res["draft"].rsplit("\n\n", 1)[0] + "\n\nCheers!"
                row["quality"] = agent.audit(em["id"], bad_text)
            else:
                row["quality"] = agent.report_outcome(em["id"], good=True)
            row["auto_n"] = auto_n
        log.append(row)
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "inbox_run_log.json").write_text(json.dumps(log, indent=1, default=str))
        (out_dir / "inbox_events.json").write_text(json.dumps(agent.events(), indent=1, default=str))
    return {"log": log, "summary": agent.summary(), "events": agent.events()}
