"""Learning from human edits.

We learn small, auditable *style rules* per email category from (draft -> final) diffs:
  greeting  - replacement first line (customer's first name becomes {first})
  signoff   - replacement closing block (text after the last blank line)
  suppress  - short boilerplate lines the human deleted
  add       - short lines the human inserted
This is deliberately simple and explainable; it does not learn content changes to the
documentation-derived answer itself (those stay a human job).
"""
from __future__ import annotations
import copy

DEFAULT_GREETING = "Hi {first},"
DEFAULT_SIGNOFF = "Best regards,\nSupport Team"
EMPTY = {"greeting": None, "signoff": None, "suppress": [], "add": []}


def new_rules() -> dict:
    return copy.deepcopy(EMPTY)


def render(parts: dict, rules: dict, first: str) -> str:
    """parts: {'body': [lines], 'sources': [lines]}"""
    greeting = (rules.get("greeting") or DEFAULT_GREETING).replace("{first}", first)
    body = [l for l in parts["body"] if l.strip() not in set(rules.get("suppress", []))]
    body += [l for l in rules.get("add", []) if l not in body]
    chunks = [greeting, "\n".join(body)]
    if parts.get("sources"):
        chunks.append("\n".join(parts["sources"]))
    chunks.append(rules.get("signoff") or DEFAULT_SIGNOFF)
    return "\n\n".join(c for c in chunks if c.strip())


def _blocks(text: str) -> list[str]:
    return [b.strip() for b in text.strip().split("\n\n")]


def learn(draft: str, final: str, first: str, rules: dict) -> list[str]:
    """Update `rules` in place from a human edit. Returns human-readable list of what was learned."""
    learned = []
    d, f = _blocks(draft), _blocks(final)
    dg, fg = d[0], f[0]
    if dg != fg and len(f) > 1:
        new = fg.replace(first, "{first}") if first in fg else fg
        if new != rules.get("greeting"):
            rules["greeting"] = new; learned.append(f"greeting -> {new!r}")
    if d[-1] != f[-1] and len(f) > 1:
        if f[-1] != rules.get("signoff"):
            rules["signoff"] = f[-1]; learned.append(f"signoff -> {f[-1]!r}")
    d_mid = [l.strip() for b in d[1:-1] for l in b.split("\n") if l.strip()]
    f_mid = {l.strip() for b in f[1:-1] for l in b.split("\n") if l.strip()}
    for l in d_mid:
        short = len(l.split()) <= 12 and not l.startswith("[") and not l.startswith("Sources")
        if short and l not in f_mid and l not in rules["suppress"]:
            rules["suppress"].append(l); learned.append(f"suppress line {l!r}")
    d_set = set(d_mid)
    for l in f_mid:
        if len(l.split()) <= 20 and l not in d_set and not l.startswith("[") and l not in rules["add"]:
            rules["add"].append(l); learned.append(f"add line {l!r}")
    return learned
