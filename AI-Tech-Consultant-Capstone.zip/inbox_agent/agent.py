"""Inbox Agent: classify -> draft (via Knowledge Brain API) -> human review -> learn -> earn auto-send.

Safety rules (all enforced in code, covered by tests):
  * Auto-send is earned PER CATEGORY after AUTO_SEND_THRESHOLD (20) CONSECUTIVE drafts approved UNCHANGED.
  * Any human edit of an eligible draft resets that category's streak to 0.
  * Only drafts grounded in documentation (Brain status 'answered', confidence >= MIN_CONF) are eligible.
  * Sensitive categories (billing, cancellation, complaint) and spam can NEVER be auto-sent.
  * Quality monitor: in the last QUALITY_WINDOW auto-sent emails (current epoch), >= MAX_BAD bad outcomes
    => auto-send SUSPENDED, learned rules ROLLED BACK to the snapshot taken when auto-send was enabled,
    streak reset to 0. Auto-send must be re-earned with another 20 unchanged drafts.
  * "Sending" is simulated (rows in an outbox table). No real email is ever sent by this project.
"""
from __future__ import annotations
import json, re, sqlite3, threading, time
from common.brain_client import BrainClient, BrainUnavailable
from . import rules as R
from .classifier import classify

AUTO_SEND_THRESHOLD = 20
QUALITY_WINDOW = 5
MAX_BAD = 2
MIN_CONF = 0.55
NEVER_AUTO = {"billing", "cancellation", "complaint", "spam"}
USES_DOCS = {"how_to", "bug_report", "billing", "sales_inquiry"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS mails(
  email_id TEXT PRIMARY KEY, seq INTEGER, name TEXT, category TEXT, decision TEXT,
  draft TEXT, final TEXT, brain_status TEXT, confidence REAL, eligible INTEGER, edited INTEGER,
  sent INTEGER DEFAULT 0, auto_sent INTEGER DEFAULT 0, epoch INTEGER DEFAULT 0, outcome INTEGER);
CREATE TABLE IF NOT EXISTS state(category TEXT PRIMARY KEY, streak INTEGER DEFAULT 0, auto_enabled INTEGER DEFAULT 0,
  suspended INTEGER DEFAULT 0, epoch INTEGER DEFAULT 0, snapshot TEXT, rules TEXT);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, category TEXT, kind TEXT, detail TEXT);
"""


class InboxAgent:
    def __init__(self, brain: BrainClient, db_path=":memory:"):
        self.brain = brain
        self.db = sqlite3.connect(str(db_path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.db.executescript(SCHEMA)
        self._seq = 0

    # ---------- state helpers ----------
    def _state(self, cat: str) -> dict:
        row = self.db.execute("SELECT * FROM state WHERE category=?", (cat,)).fetchone()
        if not row:
            self.db.execute("INSERT INTO state(category, rules) VALUES(?,?)", (cat, json.dumps(R.new_rules())))
            self.db.commit()
            row = self.db.execute("SELECT * FROM state WHERE category=?", (cat,)).fetchone()
        d = dict(row); d["rules"] = json.loads(d["rules"]); return d

    def _save(self, cat, **kw):
        for k, v in kw.items():
            if k in ("rules", "snapshot") and v is not None and not isinstance(v, str):
                v = json.dumps(v)
            self.db.execute(f"UPDATE state SET {k}=? WHERE category=?", (v, cat))
        self.db.commit()

    def _event(self, cat, kind, detail=""):
        self.db.execute("INSERT INTO events(ts,category,kind,detail) VALUES(?,?,?,?)", (time.time(), cat, kind, str(detail)))
        self.db.commit()

    def state(self, cat: str) -> dict:
        with self.lock:
            s = self._state(cat); s.pop("snapshot", None); return s

    def events(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM events ORDER BY id")]

    # ---------- 1. process ----------
    def process(self, email: dict) -> dict:
        with self.lock:
            self._seq += 1
            text = email.get("text") or self._extract_text(email["body"])
            first = email["name"].split()[0]
            cat, _ = classify(email.get("subject", "") + ". " + text)
            if cat == "spam":
                self._insert(email, cat, "archived_spam", "", None, 0.0, False)
                return {"email_id": email["id"], "category": cat, "decision": "archived_spam", "draft": ""}

            brain_res, brain_err = None, None
            try:
                brain_res = self.brain.ask(text)
            except BrainUnavailable as e:
                brain_err = str(e)
            st = self._state(cat)
            parts, b_status, conf = self._build_parts(cat, text, brain_res, brain_err, email)
            draft = R.render(parts, st["rules"], first)
            eligible = (cat not in NEVER_AUTO and b_status == "answered" and conf >= MIN_CONF)

            if eligible and st["auto_enabled"] and not st["suspended"]:
                decision = "auto_sent"
            else:
                decision = "needs_review"
            self._insert(email, cat, decision, draft, b_status, conf, eligible,
                         auto=decision == "auto_sent", epoch=st["epoch"])
            return {"email_id": email["id"], "category": cat, "decision": decision, "draft": draft,
                    "brain_status": b_status, "confidence": conf, "eligible": eligible}

    @staticmethod
    def _extract_text(body: str) -> str:
        blocks = [b.strip() for b in body.strip().split("\n\n")]
        return " ".join(blocks[1:-1]) if len(blocks) > 2 else body

    def _build_parts(self, cat, text, res, err, email):
        body, sources = [], []
        if err:
            body = ["Thanks for your message. We've received it and a team member will reply personally."]
            return {"body": body, "sources": []}, "brain_unavailable", 0.0
        status, conf = res["status"], res.get("confidence", 0.0)
        if cat == "how_to":
            if status == "answered":
                body = ["Thanks for reaching out! Here is what our documentation says:", res["answer"],
                        "Let us know if you have any other questions."]
                sources = ["Sources:"] + [f"[{c['n']}] {c['title']} ({c['url']})" for c in res["citations"]]
            else:
                tid = None
                try:
                    tid = self.brain.escalate(text, email["from"], "inbox agent: no documented answer")["ticket_id"]
                except BrainUnavailable:
                    pass
                body = ["Thanks for reaching out! I couldn't find a documented answer to this, so I don't want to guess.",
                        f"I've passed your question to a specialist{f' (ticket #{tid})' if tid else ''} who will reply personally."]
        elif cat == "billing":
            body = ["Thanks for contacting us about your billing. I've flagged your message for our billing team, "
                    "who will review your account and reply within one business day."]
        elif cat == "bug_report":
            body = ["Thanks for the report - I've logged it for our technical team. "
                    "Could you reply with the page URL and a screenshot so we can reproduce it?"]
            if status == "answered":
                body.append(f"In the meantime this documentation may help: {res['answer']}")
                sources = ["Sources:"] + [f"[{c['n']}] {c['title']} ({c['url']})" for c in res["citations"]]
        elif cat == "feature_request":
            body = ["Thanks for the suggestion! I've shared it with our product team. "
                    "We can't promise a timeline, but requests like yours help us prioritise."]
        elif cat == "cancellation":
            body = ["I'm sorry to see you go. I've passed your request to our accounts team, who will confirm "
                    "the cancellation and any remaining billing with you directly."]
        elif cat == "complaint":
            body = ["I'm sorry about your experience. I've escalated your message to a senior team member "
                    "who will contact you personally."]
        elif cat == "sales_inquiry":
            body = ["Thanks for your interest! A member of our sales team will follow up with pricing details shortly."]
        else:
            body = ["Thanks for your message. A team member will review it and reply."]
        return {"body": body, "sources": sources}, status, conf

    def _insert(self, email, cat, decision, draft, b_status, conf, eligible, auto=False, epoch=0):
        self.db.execute(
            "INSERT OR REPLACE INTO mails(email_id,seq,name,category,decision,draft,brain_status,confidence,eligible,edited,sent,auto_sent,epoch)"
            " VALUES(?,?,?,?,?,?,?,?,?,0,?,?,?)",
            (email["id"], self._seq, email["name"], cat, decision, draft, b_status, conf, int(eligible),
             int(auto), int(auto), epoch))
        self.db.commit()

    # ---------- 2. human review ----------
    @staticmethod
    def _norm(t): return re.sub(r"\s+", " ", t or "").strip()

    def review(self, email_id: str, final_text: str | None = None) -> dict:
        """Human approves (final_text None / identical) or edits-and-sends a drafted reply."""
        with self.lock:
            m = self.db.execute("SELECT * FROM mails WHERE email_id=?", (email_id,)).fetchone()
            if not m or m["decision"] != "needs_review":
                raise ValueError(f"{email_id} is not awaiting review")
            cat, first = m["category"], m["name"].split()[0]
            unchanged = final_text is None or self._norm(final_text) == self._norm(m["draft"])
            st, learned, event = self._state(cat), [], None
            if not unchanged:
                learned = R.learn(m["draft"], final_text, first, st["rules"])
                self._save(cat, rules=st["rules"])
                self._event(cat, "edit_learned", f"{email_id}: {learned}")
            if m["eligible"]:
                streak = st["streak"] + 1 if unchanged else 0
                self._save(cat, streak=streak)
                if streak >= AUTO_SEND_THRESHOLD and not st["auto_enabled"]:
                    self._save(cat, auto_enabled=1, suspended=0, snapshot=self._state(cat)["rules"])
                    event = "auto_send_enabled"
                    self._event(cat, event, f"after {streak} consecutive unchanged drafts (threshold {AUTO_SEND_THRESHOLD})")
                elif not unchanged:
                    self._event(cat, "streak_reset", f"{email_id} edited; streak {st['streak']} -> 0")
            self.db.execute("UPDATE mails SET final=?, edited=?, sent=1, decision='sent_after_review' WHERE email_id=?",
                            (final_text if not unchanged else m["draft"], int(not unchanged), email_id))
            self.db.commit()
            return {"unchanged": unchanged, "learned": learned, "event": event, "streak": self._state(cat)["streak"]}

    # ---------- 3. quality monitor ----------
    def report_outcome(self, email_id: str, good: bool) -> dict:
        """Quality signal for an AUTO-SENT email (e.g. customer says it didn't help, or an audit fails)."""
        with self.lock:
            m = self.db.execute("SELECT * FROM mails WHERE email_id=?", (email_id,)).fetchone()
            if not m or not m["auto_sent"]:
                raise ValueError(f"{email_id} was not auto-sent")
            self.db.execute("UPDATE mails SET outcome=? WHERE email_id=?", (int(good), email_id)); self.db.commit()
            cat = m["category"]; st = self._state(cat)
            if not st["auto_enabled"]:
                return {"suspended": False}
            rows = self.db.execute(
                "SELECT outcome FROM mails WHERE category=? AND auto_sent=1 AND epoch=? AND outcome IS NOT NULL "
                "ORDER BY seq DESC LIMIT ?", (cat, st["epoch"], QUALITY_WINDOW)).fetchall()
            bad = sum(1 for r in rows if r["outcome"] == 0)
            if bad >= MAX_BAD:
                restored = json.loads(st["snapshot"]) if st["snapshot"] else R.new_rules()
                self._save(cat, auto_enabled=0, suspended=1, streak=0, epoch=st["epoch"] + 1, rules=restored)
                self._event(cat, "auto_send_suspended_rolled_back",
                            f"{bad} bad outcomes in last {len(rows)} auto-sent; rules restored to enable-time snapshot")
                return {"suspended": True, "bad": bad, "window": len(rows), "rules_restored": restored}
            return {"suspended": False, "bad": bad, "window": len(rows)}

    def audit(self, email_id: str, corrected_text: str) -> dict:
        """Human corrects an already auto-sent reply: counts as a BAD outcome and the correction is learned
        (so a later rollback visibly discards rules learned during a bad period)."""
        with self.lock:
            m = self.db.execute("SELECT * FROM mails WHERE email_id=?", (email_id,)).fetchone()
            cat, st = m["category"], self._state(m["category"])
            R.learn(m["draft"], corrected_text, m["name"].split()[0], st["rules"])
            self._save(cat, rules=st["rules"])
            self._event(cat, "audit_correction_learned", email_id)
            return self.report_outcome(email_id, good=False)

    # ---------- reporting ----------
    def summary(self) -> dict:
        cats = {}
        for r in self.db.execute("SELECT category, decision, COUNT(*) n FROM mails GROUP BY category, decision"):
            cats.setdefault(r["category"], {})[r["decision"]] = r["n"]
        return {"by_category": cats, "state": {c["category"]: self.state(c["category"])
                                              for c in self.db.execute("SELECT category FROM state")}}
