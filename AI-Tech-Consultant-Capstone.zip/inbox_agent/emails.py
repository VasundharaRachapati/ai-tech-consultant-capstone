"""Deterministic generator for 77 SYNTHETIC customer emails with self-authored ground-truth labels.
Run: python -m inbox_agent.emails   -> writes samples/emails.json"""
import json
from pathlib import Path

HOW_TO = [
 "How do I create a new membership plan with a monthly price?", "Can I offer a free plan to some members?",
 "How can I import 800 members from a spreadsheet?", "What columns do I need in my CSV file for importing members?",
 "How do I connect my own domain name to my directory?", "How long does it take for DNS changes to work after I set my domain?",
 "How do I get the HTTPS padlock on my site?", "Why does my browser say my site is not secure?",
 "How do I change the text of the welcome email?", "How can I stop my site emails from going to spam?",
 "How do I connect Stripe so members can pay by card?", "What happens when a member's renewal payment fails?",
 "How do I issue a refund to a member?", "If a member upgrades mid-month, how is the price calculated?",
 "How do I show search results on a map?", "How do I get rid of the development purposes only watermark on my map?",
 "How do lead forms choose which members get a request?", "How do I change the title tag and meta description of my pages?",
 "How can I create one page per city for local SEO?", "How do I add a testimonial slider to my homepage?",
 "How do I approve a pending member listing?", "How can I make new listings go live without approval?",
 "How do I send a webhook to Zapier when someone signs up?", "How do I create a staff account that can approve listings but not edit payments?",
 "How do I restore my site from last night's backup?", "How do I back up my site before a big import?",
 "How can visitors leave star ratings on a member profile?", "How do I let members reply to reviews on their profile?",
 "Where do I set the number of search results per page?", "How do I add a Google Maps API key?",
 "How do I hide a plan from the public signup page?", "How do I customize the lead notification email?",
 "How do I export reviews to a CSV file?", "Where do I find a member's billing history?",
 "How do I filter search results by city and rating?", "How do I give a moderator access to reviews only?",
 "How do I change which fields appear on the lead form?", "How do I show a map pin for each member in search results?",
 "How can I give featured placement to members on a higher plan?", "How do I send a test version of an email template to myself?",
 "Where do I turn on reviews for member profiles?", "How do I download a copy of my backup?",
 "How can I check if my SSL certificate was issued?", "How do I set up a CNAME record for my domain?",
]
HOW_TO_UNKNOWN = ["How do I set up WhatsApp notifications for new leads?", "How do I translate my directory into Spanish?",
                  "How do I connect my directory to QuickBooks?"]
OTHERS = {
 "billing": ["I was charged twice for my membership this month, please check my invoice.",
             "Why was my card charged $49 when I thought the plan was $39?",
             "My payment failed but my account still shows paid, can you look at my billing?",
             "Can I get a refund for last month's invoice? I barely used the site.",
             "I need a copy of my invoice for March for my accountant.",
             "I got a payment failed email but my card is fine, please check the charge."],
 "bug_report": ["The search page shows an error when I filter by city.",
                "Bug: uploaded photos are not showing on my profile, it's broken.",
                "My site crashes whenever I open the member list.",
                "The contact form is not working - no emails arrive.",
                "Getting error 500 on checkout.", "The login page is broken on mobile Safari."],
 "feature_request": ["Feature request: please add a dark mode for the admin panel.",
                     "It would be great if members could export their leads to Excel.",
                     "Please add support for multiple languages in the member dashboard.",
                     "I suggest adding a calendar booking feature for listings."],
 "cancellation": ["Please cancel my subscription effective today.", "I want to close my account and delete my data.",
                  "Cancel my membership, I'm moving to a different platform."],
 "complaint": ["This is unacceptable! Your support has ignored me for a week.",
               "I am furious - the worst service I have experienced.",
               "Terrible experience, my site was down all weekend and nobody told me.",
               "I'm very disappointed with how the last update broke my layout. This is unacceptable."],
 "sales_inquiry": ["Do you offer enterprise pricing for 50 sites? I'd like a quote.",
                   "Can I get a demo of the platform for my agency?",
                   "How much does the pro plan cost for a directory of 5000 members?",
                   "We're evaluating platforms - can someone send pricing?"],
 "spam": ["CONGRATULATIONS winner! Click here to claim your free crypto bonus.",
          "Guaranteed #1 Google ranking in 24 hours - SEO services special offer, click here.",
          "Buy cheap followers now - limited offer, unsubscribe below."],
}
NAMES = ["Priya Nair", "Tom Becker", "Aisha Khan", "Luis Moreno", "Hannah Weiss", "Kenji Sato", "Olga Petrova",
         "Marcus Reid", "Sofia Rossi", "Daniel Okafor", "Mei Lin", "Carlos Vega", "Fatima Zahra", "Jack Turner"]


def build() -> list[dict]:
    hows = list(HOW_TO)
    for pos, q in zip((8, 21, 31), HOW_TO_UNKNOWN):
        hows.insert(pos, q)
    others = [(c, t) for c, ts in OTHERS.items() for t in ts]
    seq, oi = [], 0
    for i, h in enumerate(hows):
        seq.append(("how_to", h))
        if i % 2 == 0 and oi < len(others):
            seq.append(others[oi]); oi += 1
    seq += others[oi:]
    out = []
    for n, (cat, text) in enumerate(seq, 1):
        name = NAMES[n % len(NAMES)]
        first = name.split()[0]
        out.append({"id": f"E{n:03d}", "from": f"{first.lower()}{n}@example.com", "name": name,
                    "subject": text[:50].rstrip(" ?.") , "text": text,
                    "body": f"Hi support team,\n\n{text}\n\nThanks,\n{first}", "true_category": cat})
    return out


if __name__ == "__main__":
    e = build()
    p = Path(__file__).resolve().parent.parent / "samples" / "emails.json"
    p.write_text(json.dumps(e, indent=1)); print(f"wrote {len(e)} emails -> {p}")
