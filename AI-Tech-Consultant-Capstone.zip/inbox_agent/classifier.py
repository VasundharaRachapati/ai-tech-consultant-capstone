"""Rule-based email classifier (deterministic, offline). Order matters - first match wins."""
import re

RULES = [
 ("spam", r"congratulations|winner|click here|crypto|guaranteed #?1|buy cheap|limited offer|unsubscribe"),
 ("cancellation", r"\bcancel (my|the|our)\b|close my account|stop my subscription|delete my (account|data)"),
 ("complaint", r"unacceptable|furious|terrible|worst|disappointed|ignored me"),
 ("how_to", r"\bhow (do|can|should|would) (i|we)\b|\bwhere (do|can) (i|we)\b|\bhow to\b|\bwhat should i do\b"),
 ("billing", r"charged|invoice|payment failed|billing problem|refund for|double charge"),
 ("bug_report", r"\berror\b|\bbug\b|crash|broken|not working|doesn'?t work|\b500\b"),
 ("feature_request", r"feature request|would be great if|please add|i suggest|wish (it|you) could"),
 ("sales_inquiry", r"pricing|\bquote\b|\bdemo\b|enterprise|how much|\bcost\b"),
 ("how_to", r"\bcan i\b|is it possible|\?|^why\b|what happens"),
]


def classify(text: str) -> tuple[str, str]:
    t = text.lower()
    for cat, pat in RULES:
        if re.search(pat, t):
            return cat, pat
    return "other", ""
