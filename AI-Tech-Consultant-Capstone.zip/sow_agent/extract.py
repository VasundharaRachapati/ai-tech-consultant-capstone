"""Parse transcripts, extract client requirements and constraints (deterministic, rule-based)."""
from __future__ import annotations
import re
from pathlib import Path
from .catalog import FEATURES, OUT_OF_SCOPE, DROP_RE, CUE_RE

MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December"


def parse_meeting(text: str, name: str = "") -> dict:
    head, _, body = text.partition("\n\n")
    meta = dict(l.split(": ", 1) for l in head.splitlines() if ": " in l)
    roles = {}
    for m in re.finditer(r"([A-Z][\w.'-]+(?: [A-Z][\w.'-]+)*) \((Client|Consultant)\)", meta.get("Attendees", "")):
        roles[m.group(1)] = m.group(2)
    turns = []
    for line in body.splitlines():
        m = re.match(r"^([A-Z][\w.'-]+(?: [A-Z][\w.'-]+)?):\s*(.+)$", line.strip())
        if m:
            speaker = next((full for full in roles if full.split()[0] == m.group(1) or full == m.group(1)), m.group(1))
            turns.append((speaker, roles.get(speaker, "Unknown"), m.group(2)))
    return {"file": name, "title": meta.get("Meeting", name), "date": meta.get("Date", ""),
            "type": meta.get("Type", "meeting"), "turns": turns}


def split_sentences(t: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z])", t) if s.strip()]


def find_feature(sentence: str):
    s = sentence.lower()
    for fid, f in OUT_OF_SCOPE.items():
        if re.search(f["kw"], s):
            return "out_of_scope", fid
    hits = [fid for fid, f in FEATURES.items() if re.search(f["kw"], s)]
    return ("in_scope", hits) if hits else (None, None)


def extract_constraints(sentence: str) -> dict:
    out = {}
    m = re.search(r"\$\s?([\d,]+)(k)?", sentence, re.I)
    if m and re.search(r"budget", sentence, re.I):
        v = int(m.group(1).replace(",", "")) * (1000 if m.group(2) else 1)
        out["budget"] = v
    m = re.search(rf"\b({MONTHS})\s+(\d{{1,2}})\b", sentence)
    if m and re.search(r"launch|go live|deadline|deliver", sentence, re.I):
        out["deadline"] = f"{m.group(1)} {m.group(2)}"
    return out


def extract(meetings: list[dict]) -> dict:
    """Return {'requirements': [...], 'dropped': [...], 'constraints': {...}, 'history': [...]}."""
    reqs, dropped, history, constraints = [], [], [], {}
    for mt in sorted(meetings, key=lambda m: m["date"]):
        for speaker, role, text in mt["turns"]:
            if role != "Client":
                continue
            sents = split_sentences(text)
            for i, s in enumerate(sents):
                c = extract_constraints(s)
                if c:
                    for k, v in c.items():
                        if constraints.get(k) not in (None, v):
                            history.append({"field": k, "from": constraints[k], "to": v, "meeting": mt["title"], "date": mt["date"]})
                        constraints[k] = v
                    continue
                if re.search(DROP_RE, s, re.I):
                    kind, hit = find_feature(s)
                    if not hit and i > 0:
                        kind, hit = find_feature(sents[i - 1])
                    ids = ([hit] if kind == "out_of_scope" else hit) if hit else []
                    dropped.append({"text": s, "features": ids, "meeting": mt["title"], "speaker": speaker})
                    continue
                if re.search(CUE_RE, s, re.I):
                    kind, hit = find_feature(s)
                    reqs.append({"text": s, "meeting": mt["title"], "date": mt["date"], "speaker": speaker,
                                 "kind": kind or "unmapped",
                                 "features": ([hit] if kind == "out_of_scope" else hit) if hit else []})
    return {"requirements": reqs, "dropped": dropped, "constraints": constraints, "history": history}


def load_meetings(folder: Path) -> list[dict]:
    return [parse_meeting(p.read_text(encoding="utf-8"), p.name) for p in sorted(Path(folder).glob("*.txt"))]
