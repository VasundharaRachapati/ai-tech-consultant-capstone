"""CLI:  python -m sow_agent.cli run|approve|finalize   (needs the Brain API running; see README)"""
import argparse, sys
from pathlib import Path
from common.brain_client import BrainClient
from . import pipeline

ROOT = Path(__file__).resolve().parent.parent


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["run", "approve", "finalize"])
    ap.add_argument("--meetings", default=str(ROOT / "samples" / "meetings"))
    ap.add_argument("--out", default=str(ROOT / "samples" / "output" / "sow"))
    ap.add_argument("--approver", default="")
    ap.add_argument("--ack-open-items", action="store_true", help="confirm you have read the open items list")
    a = ap.parse_args(argv)
    out = Path(a.out)
    if a.cmd == "run":
        r = pipeline.run(Path(a.meetings), out, BrainClient())
        print(f"SOW written to {out} ({r['sow']['totals']['total_hours']} h, status {r['sow']['status']})")
    elif a.cmd == "approve":
        try:
            print(pipeline.approve(out, a.approver, a.ack_open_items))
        except (pipeline.ApprovalRequired, ValueError) as e:
            print("REFUSED:", e, "(read the open items in proposal_DRAFT.md, then re-run with --ack-open-items)"); sys.exit(2)
    else:
        try:
            print("written", pipeline.finalize(out))
        except pipeline.ApprovalRequired as e:
            print("REFUSED:", e); sys.exit(2)


if __name__ == "__main__":
    main()
