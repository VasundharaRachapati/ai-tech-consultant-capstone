"""Meeting transcripts -> requirements -> Brain-verified scope -> tasks/hours -> proposal -> human approval gate."""
from __future__ import annotations
import csv, hashlib, io, json, os, time
from pathlib import Path
from common.brain_client import BrainClient, BrainUnavailable
from .catalog import FEATURES, OUT_OF_SCOPE, OVERHEAD, QA_PCT, PM_PCT, CONTINGENCY_PCT
from .extract import extract, load_meetings

DRAFT_BANNER = "> **DRAFT - NOT APPROVED. Do not send to the client until a human has approved this document.**"


class ApprovalRequired(Exception):
    pass


def _brain_check(brain: BrainClient, question: str) -> dict:
    try:
        r = brain.ask(question)
        return {"status": r["status"], "confidence": r.get("confidence"),
                "citations": [{"title": c["title"], "url": c["url"]} for c in r.get("citations", [])]}
    except BrainUnavailable as e:
        return {"status": "brain_unavailable", "confidence": 0.0, "citations": [], "error": str(e)}


def build_sow(meetings: list[dict], brain: BrainClient, client_name="Harbor & Pine Realty",
              hourly_rate: float | None = None) -> dict:
    rate = hourly_rate or float(os.getenv("SOW_HOURLY_RATE", "95"))
    ex = extract(meetings)
    dropped_ids = {fid for d in ex["dropped"] for fid in d["features"]}
    feats: dict[str, dict] = {}       # feature id -> {quotes, kind}
    unmapped, dropped_log = [], []
    for r in ex["requirements"]:
        if r["kind"] == "unmapped":
            unmapped.append(r); continue
        for fid in r["features"]:
            f = feats.setdefault(fid, {"kind": r["kind"], "quotes": []})
            f["quotes"].append({"text": r["text"], "meeting": r["meeting"], "speaker": r["speaker"]})
    for fid in sorted(dropped_ids):
        if fid in feats:
            dropped_log.append({"feature": fid, "reason": [d["text"] for d in ex["dropped"] if fid in d["features"]]})
            feats.pop(fid)
    for d in ex["dropped"]:
        if not d["features"]:
            dropped_log.append({"feature": None, "reason": [d["text"]], "note": "drop request matched no known feature"})

    in_scope, out_scope, open_items, tasks = [], [], [], []
    for fid, f in feats.items():
        if f["kind"] == "out_of_scope":
            spec = OUT_OF_SCOPE[fid]
            evidence = _brain_check(brain, spec["q"])
            out_scope.append({"id": fid, "name": spec["name"], "reason": spec["reason"], "requested_in": f["quotes"],
                              "docs_evidence": evidence,
                              "note": ("Knowledge Brain found no documentation of this capability."
                                       if evidence["status"] == "unknown" else
                                       "Brain returned related documentation - human should confirm it is still out of scope.")})
            if evidence["status"] == "answered":
                open_items.append(f"Out-of-scope item '{spec['name']}': Brain returned related docs; confirm it should stay out of scope.")
            continue
        spec = FEATURES[fid]
        evidence = _brain_check(brain, spec["q"])
        item = {"id": fid, "name": spec["name"], "requested_in": f["quotes"], "docs_evidence": evidence,
                "verified_in_docs": evidence["status"] == "answered"}
        in_scope.append(item)
        if not item["verified_in_docs"]:
            open_items.append(f"'{spec['name']}': platform documentation could not confirm this capability "
                              f"(Brain status: {evidence['status']}). Verify before committing.")
        for name, h in spec["tasks"]:
            tasks.append({"feature": fid, "task": name, "hours": h})

    needs_clar = []
    for r in unmapped:
        ev = _brain_check(brain, r["text"])
        needs_clar.append({"text": r["text"], "meeting": r["meeting"], "speaker": r["speaker"], "docs_evidence": ev,
                           "note": ("Not found in documentation - needs human decision (custom development or out of scope). "
                                    "Not included in hours." if ev["status"] != "answered" else
                                    "Brain returned possibly related docs, but the request does not map to a catalogued feature - "
                                    "needs human estimate. Not included in hours.")})
        open_items.append(f"Unestimated request needs human decision: \"{r['text']}\"")

    feature_hours = sum(t["hours"] for t in tasks)
    overhead = [{"feature": "overhead", "task": n, "hours": h} for n, h in OVERHEAD]
    overhead += [{"feature": "overhead", "task": "Testing and user acceptance (15% of feature hours)", "hours": round(feature_hours * QA_PCT, 1)},
                 {"feature": "overhead", "task": "Project management (10% of feature hours)", "hours": round(feature_hours * PM_PCT, 1)}]
    subtotal = feature_hours + sum(t["hours"] for t in overhead)
    contingency = round(subtotal * CONTINGENCY_PCT, 1)
    total_hours = round(subtotal + contingency, 1)
    cost = round(total_hours * rate)
    budget = ex["constraints"].get("budget")
    if budget and cost > budget:
        open_items.append(f"Estimated cost ${cost:,} EXCEEDS client budget ${budget:,} - discuss scope trade-offs.")

    sow = {
        "client": client_name, "generated": time.strftime("%Y-%m-%d"), "status": "DRAFT_PENDING_HUMAN_APPROVAL",
        "sources": [m["file"] for m in meetings],
        "constraints": ex["constraints"], "constraint_changes": ex["history"],
        "in_scope": in_scope, "out_of_scope": out_scope, "needs_clarification": needs_clar, "dropped": dropped_log,
        "tasks": tasks + overhead,
        "totals": {"feature_hours": feature_hours, "subtotal_hours": round(subtotal, 1), "contingency_pct": CONTINGENCY_PCT,
                   "contingency_hours": contingency, "total_hours": total_hours, "hourly_rate_assumed": rate,
                   "estimated_cost": cost, "client_budget": budget,
                   "within_budget": (cost <= budget) if budget else None},
        "open_items_for_human": open_items,
        "assumptions": ["Hour estimates are planning assumptions from a fixed catalog, not measured data.",
                        f"Hourly rate ${rate:g} is a placeholder (set SOW_HOURLY_RATE).",
                        "Platform capabilities were checked against the documentation available to the Knowledge Brain "
                        "(local synthetic fallback unless a live crawl succeeded)."],
    }
    return sow


def _hash(sow: dict) -> str:
    return hashlib.sha256(json.dumps(sow, sort_keys=True).encode()).hexdigest()


def render_markdown(sow: dict, final: dict | None = None) -> str:
    t, c = sow["totals"], sow["constraints"]
    L = [f"# Proposal and Scope of Work - {sow['client']}", "",
         (f"**APPROVED** by {final['approver']} on {final['approved_at']}." if final else DRAFT_BANNER), "",
         f"_Generated {sow['generated']} from: {', '.join(sow['sources'])}_", "",
         "## 1. Summary", "",
         f"Based on {len(sow['sources'])} client conversations we propose a directory platform configured to your needs. "
         f"Client budget: {('$' + format(c['budget'], ',')) if c.get('budget') else 'not stated'}; "
         f"target launch: {c.get('deadline', 'not stated')}.", ""]
    if sow["constraint_changes"]:
        L += ["Constraint changes over time: " + "; ".join(
            f"{h['field']} {h['from']} -> {h['to']} ({h['meeting']})" for h in sow["constraint_changes"]), ""]
    L += ["## 2. In scope", ""]
    for i in sow["in_scope"]:
        ev = ", ".join(f"[{x['title']}]({x['url']})" for x in i["docs_evidence"]["citations"]) or "no documentation found"
        flag = "" if i["verified_in_docs"] else " **(NOT verified in docs)**"
        L.append(f"- **{i['name']}**{flag} - docs: {ev}")
    L += ["", "## 3. Out of scope (requested but not included)", ""]
    for o in sow["out_of_scope"]:
        L.append(f"- **{o['name']}** - {o['reason']} {o['note']}")
    if sow["dropped"]:
        L += ["", "## 4. Removed at client request", ""]
        L += [f"- {d['feature'] or 'unmatched'}: \"{d['reason'][0]}\"" for d in sow["dropped"]]
    L += ["", "## 5. Requests needing a human decision (not estimated)", ""]
    L += [f"- \"{n['text']}\" - {n['note']}" for n in sow["needs_clarification"]] or ["- none"]
    L += ["", "## 6. Tasks and estimated hours", "", "| Feature | Task | Hours |", "|---|---|---|"]
    L += [f"| {x['feature']} | {x['task']} | {x['hours']} |" for x in sow["tasks"]]
    L += ["", f"Subtotal {t['subtotal_hours']} h + {int(t['contingency_pct']*100)}% contingency ({t['contingency_hours']} h) "
          f"= **{t['total_hours']} h**. At the assumed ${t['hourly_rate_assumed']:g}/h: **${t['estimated_cost']:,}**"
          + (f" vs budget ${t['client_budget']:,} - {'within' if t['within_budget'] else '**EXCEEDS**'} budget." if t['client_budget'] else "."), "",
          "## 7. Assumptions", ""] + [f"- {a}" for a in sow["assumptions"]]
    L += ["", "## 8. Open items for the human approver", ""] + [f"- [ ] {o}" for o in sow["open_items_for_human"]]
    return "\n".join(L) + "\n"


def write_outputs(sow: dict, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "sow.json").write_text(json.dumps(sow, indent=1))
    (out_dir / "proposal_DRAFT.md").write_text(render_markdown(sow))
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(["feature", "task", "hours"])
    for x in sow["tasks"]:
        w.writerow([x["feature"], x["task"], x["hours"]])
    (out_dir / "tasks.csv").write_text(buf.getvalue())
    return {"sow_hash": _hash(sow)}


def approve(out_dir: Path, approver: str, acknowledge_open_items: bool = False) -> dict:
    sow = json.loads((out_dir / "sow.json").read_text())
    if not approver.strip():
        raise ValueError("approver name required")
    if sow["open_items_for_human"] and not acknowledge_open_items:
        raise ApprovalRequired(f"{len(sow['open_items_for_human'])} open items must be explicitly acknowledged")
    rec = {"approver": approver, "approved_at": time.strftime("%Y-%m-%d %H:%M"), "sow_hash": _hash(sow),
           "acknowledged_open_items": sow["open_items_for_human"]}
    (out_dir / "approval.json").write_text(json.dumps(rec, indent=1))
    return rec


def finalize(out_dir: Path) -> Path:
    """Write the client-ready proposal ONLY if a human approval matches the current SOW content."""
    ap = out_dir / "approval.json"
    if not ap.exists():
        raise ApprovalRequired("no human approval on record - run `approve` first")
    sow = json.loads((out_dir / "sow.json").read_text())
    rec = json.loads(ap.read_text())
    if rec["sow_hash"] != _hash(sow):
        raise ApprovalRequired("SOW changed after approval - re-approval required")
    p = out_dir / "proposal_FINAL.md"
    p.write_text(render_markdown(sow, final=rec))
    return p


def run(meetings_dir: Path, out_dir: Path, brain: BrainClient) -> dict:
    sow = build_sow(load_meetings(meetings_dir), brain)
    info = write_outputs(sow, out_dir)
    return {"sow": sow, **info}
