"""Feature catalog (keywords -> work breakdown) and out-of-scope patterns.

The hour estimates are PLANNING ASSUMPTIONS written by the project author, not measured data.
Each feature has a canonical documentation question that is sent to the Knowledge Brain API
to verify the platform documents that capability.
"""
FEATURES = {
 "membership_plans": dict(name="Membership plans / tiers", kw=r"membership|tier|plans?\b|subscription",
    q="How do I create a membership plan?",
    tasks=[("Design plan structure and feature limits", 3), ("Configure free/paid plans", 4), ("Signup page and plan visibility", 3), ("Test upgrade/downgrade flows", 2)]),
 "csv_import": dict(name="Bulk listing import (CSV)", kw=r"import|spreadsheet|csv|existing .*listings",
    q="How do I import members from a CSV file?",
    tasks=[("Clean and map source spreadsheet", 5), ("Run test import and fix rejects", 3), ("Run full import and verify", 3)]),
 "custom_domain_ssl": dict(name="Custom domain and HTTPS", kw=r"\bdomain\b|https|ssl",
    q="How do I connect a custom domain?",
    tasks=[("DNS records and domain settings", 3), ("SSL verification and force-HTTPS", 2), ("Redirect testing", 1)]),
 "payments": dict(name="Card payments (Stripe)", kw=r"stripe|credit card|payment gateway|accept .*payments?|membership fees",
    q="How do I connect Stripe for membership payments?",
    tasks=[("Stripe account connection (test mode)", 3), ("Paid plan checkout testing", 4), ("Failed-renewal and grace-period setup", 3), ("Go-live switch to live keys", 1)]),
 "search_map": dict(name="Search by city with map results", kw=r"search by|\bmap\b|google maps|search results|search page",
    q="How do I show search results on a map?",
    tasks=[("Search layout and filters (city, category)", 5), ("Google Maps API key and map view", 4), ("Result sorting and featured placement", 3), ("Cross-device testing", 2)]),
 "lead_routing": dict(name="Lead forms and routing", kw=r"\bleads?\b.*(route|match)|contact form|lead form|route[d]? to",
    q="How do lead forms decide which members get a lead?",
    tasks=[("Lead form fields and embedding", 4), ("Matching rules (city + service)", 6), ("Lead storage and admin review", 3), ("Testing with sample leads", 3)]),
 "email_notifications": dict(name="Branded email notifications", kw=r"email notification|notifications? to agents|branded|email template|wording",
    q="How do I customize email templates?",
    tasks=[("Draft branded copy for templates", 3), ("Configure templates and placeholders", 3), ("SPF/DKIM and test sends", 2)]),
 "seo_city_pages": dict(name="SEO city landing pages", kw=r"\bseo\b|landing pages?|local search",
    q="How do I create SEO pages for each city?",
    tasks=[("Title/meta templates", 3), ("City page template and generation", 6), ("Sitemap submission", 1), ("Content QA", 2)]),
 "reviews": dict(name="Star reviews and ratings", kw=r"reviews?\b|star|ratings?",
    q="How can visitors leave star ratings and reviews?",
    tasks=[("Enable and configure reviews", 3), ("Moderation workflow", 3), ("Display ratings in search", 2), ("Testing", 2)]),
 "staff_roles": dict(name="Staff accounts and permissions", kw=r"staff accounts?|permissions?|moderators?",
    q="How do I create staff accounts with limited permissions?",
    tasks=[("Define roles", 2), ("Create staff accounts and test restrictions", 3), ("Document access policy", 1)]),
 "backups": dict(name="Nightly backups", kw=r"backups?",
    q="How do backups and restores work?",
    tasks=[("Confirm backup schedule and retention", 1), ("Restore drill", 2)]),
 "approval_workflow": dict(name="Listing approval workflow", kw=r"approved|approve|before they go live|approval",
    q="How do I approve a pending member listing?",
    tasks=[("Enable approval setting", 1), ("Approval email wording", 1), ("Moderator training notes", 1)]),
 "webhooks_crm": dict(name="Webhook / Zapier CRM sync", kw=r"webhook|zapier|\bcrm\b",
    q="How do I send a webhook when a new member signs up?",
    tasks=[("Webhook configuration for signup event", 3), ("Zapier zap to CRM and mapping", 4), ("End-to-end test", 2)]),
}

# Checked BEFORE the catalog. If matched -> classified out of scope (still sanity-checked against the Brain).
OUT_OF_SCOPE = {
 "native_mobile_app": dict(name="Native iOS/Android app", kw=r"\bios\b|iphone|android|native (mobile )?app|mobile app",
    q="Does the platform support native iOS and Android apps?",
    reason="Native mobile apps are separate app-store development, not configuration of the directory platform."),
 "erp_integration": dict(name="SAP / ERP payment integration", kw=r"\bsap\b|\berp\b|legacy system|netsuite|oracle",
    q="Can I integrate payments with SAP ERP?",
    reason="Custom ERP integration needs bespoke development and access to the client's SAP environment."),
 "whatsapp_chatbot": dict(name="WhatsApp chatbot", kw=r"whatsapp|chatbot|chat bot",
    q="How do I set up a WhatsApp chatbot?",
    reason="A conversational chatbot is a separate AI/bot project, not a documented platform feature."),
 "video_hosting": dict(name="Live video / virtual tours", kw=r"live ?stream|video tour|virtual tour",
    q="How do I host live video tours?",
    reason="Video hosting/streaming is a third-party service integration outside this scope."),
}

DROP_RE = r"no longer need|don'?t need|do not need|\bdrop\b|not needed|scrap|remove .* from scope|take .* out of scope"
CUE_RE = (r"\b(we|i)\s+(also\s+)?(need|want|must|would like|'d like|would also like)\b|\bwe'?d like\b|\bit (must|has to)\b|"
          r"\bshould be able to\b|\bneeds? to\b|\bcan you (also )?(add|build|include)\b|\bideally\b|\bplease add\b|"
          r"\b(must|needs?)\b|\bwould (also )?like\b|\bleads? .* must\b")

OVERHEAD = [("Project kickoff and discovery wrap-up", 6), ("Training and handover", 6)]
QA_PCT, PM_PCT, CONTINGENCY_PCT = 0.15, 0.10, 0.15
