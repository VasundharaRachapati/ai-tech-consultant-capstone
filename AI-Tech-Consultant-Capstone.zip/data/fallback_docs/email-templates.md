title: Customize Email Templates
url: local://fallback/email-templates

Your directory sends automatic emails such as welcome messages, password resets, and lead notifications. Each message uses an email template that you can edit. Open Email Templates in the admin panel, pick a template, and change the subject and body.

Use placeholder tags such as the member name or the site name to insert personal details automatically. Use the Send Test button to email a preview to yourself before saving. Templates support basic formatting and images. If emails land in spam, set up SPF and DKIM records for your sending domain.
