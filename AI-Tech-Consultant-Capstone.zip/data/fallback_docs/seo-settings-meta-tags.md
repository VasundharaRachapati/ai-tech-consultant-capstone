title: SEO Settings and Meta Tags
url: local://fallback/seo-settings-meta-tags

Search engine optimization settings control how your pages appear in search engines. Each page type, such as home, search results, and member profile, has a title tag and a meta description that you can edit using placeholder tags like the city or category name.

An XML sitemap is generated automatically and can be submitted to search engines. Use clean URLs and add unique descriptions to important pages. Location pages, such as one page per city, help rank for local searches and can be created from a template. After changing SEO settings, it can take days or weeks for search engines to update results.
