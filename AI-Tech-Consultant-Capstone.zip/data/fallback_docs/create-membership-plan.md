title: Create a Membership Plan
url: local://fallback/create-membership-plan

A membership plan controls what a member can do on your directory and how much they pay. To create a plan, open the Membership Plans area of the admin panel and choose Add New Plan. Give the plan a name, a price, and a billing period such as monthly or yearly.

Each plan has feature limits such as the number of photos, the number of service categories, and whether the listing is featured in search results. Set a plan to Free if members should not be charged. Plans can be hidden from the public signup page and assigned manually by an administrator. Changing the price of a plan only affects new subscribers; existing subscribers keep their current price until they change plans.
