title: Connect Stripe for Membership Payments
url: local://fallback/payment-gateway-stripe

To charge members for paid plans, connect a payment gateway. Stripe is supported for credit and debit card payments. Open Payment Settings in the admin panel, choose Stripe, and paste your Stripe publishable key and secret key from your Stripe dashboard. Enable test mode first and complete a test signup with a Stripe test card.

When test payments work, switch to live keys. Subscriptions renew automatically at the end of each billing period. If a renewal payment fails, the member is notified by email and the account can be set to downgrade to a free plan after a grace period that you configure.
