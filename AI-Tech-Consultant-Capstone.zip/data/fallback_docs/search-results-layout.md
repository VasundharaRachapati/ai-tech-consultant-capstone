title: Configure the Search Results Page
url: local://fallback/search-results-layout

The search results page shows listings that match a visitor's keywords and location. In Search Settings you can choose between a list layout, a grid layout, and a map layout. You can set how many results appear per page and which filters visitors see, such as category, city, and rating.

Featured listings from higher membership plans appear first by default. Turn on the map view to show result pins on a map; this requires a valid Google Maps API key. Sorting options include newest, alphabetical, and distance. Changes are visible right after saving, though cached pages may take a few minutes to refresh.
