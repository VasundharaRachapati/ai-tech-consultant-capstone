title: Backups and Restore
url: local://fallback/backups-and-restore

Your site data is backed up automatically each night. Backups include member data, listings, settings, and uploaded files. You can create an extra manual backup before big changes such as an import.

To restore, open Backups, choose a backup date, and select Restore. A restore replaces current data with the data from the backup, so any changes made after that date are lost. Download a backup copy to keep it outside the platform. Contact support if you need help restoring a backup older than the retention period.
