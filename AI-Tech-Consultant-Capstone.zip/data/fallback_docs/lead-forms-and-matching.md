title: Lead Forms and Lead Matching
url: local://fallback/lead-forms-and-matching

Lead forms let visitors describe what they need and send the request to relevant members. Create a lead form in the Lead Forms area and add fields such as name, email, service needed, and budget. Embed the form on any page with the provided shortcode.

Lead matching decides which members receive each lead. Matching can use the member's service category and service area. Matched members receive an email notification and can see the lead in their dashboard. You can limit the number of members per lead and charge members for leads using credits. Leads are stored for review in the admin panel.
