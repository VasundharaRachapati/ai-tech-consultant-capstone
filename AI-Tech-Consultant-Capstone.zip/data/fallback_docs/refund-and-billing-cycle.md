title: Refunds and Billing Cycles
url: local://fallback/refund-and-billing-cycle

Refunds for member payments are issued from your payment gateway dashboard, not from the directory itself. Find the charge in Stripe and choose Refund. A refund does not automatically cancel the membership; change or cancel the member's plan separately in the admin panel.

Billing cycles start on the day a member subscribes and renew on the same day each month or year. Upgrading a plan mid-cycle charges the price difference immediately. Downgrades take effect at the start of the next billing cycle. Invoices can be viewed under the member's billing history.
