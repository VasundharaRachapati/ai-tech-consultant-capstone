title: Approve or Reject New Member Listings
url: local://fallback/member-listing-approval

By default new member signups can be set to require approval. When approval is on, a new member's listing stays hidden until an administrator reviews it. Pending members appear in the Members list with a Pending status.

Open a pending member, review the profile, and choose Approve to publish the listing or Reject to decline it. The member receives an automatic email either way, and you can edit the wording in the email templates. Turn off the approval requirement in Signup Settings if you prefer new listings to go live immediately.
