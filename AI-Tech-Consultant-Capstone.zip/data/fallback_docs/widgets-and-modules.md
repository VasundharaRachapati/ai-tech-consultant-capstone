title: Add Widgets to Your Pages
url: local://fallback/widgets-and-modules

Widgets are reusable blocks of content such as a featured members slider, a search box, a testimonial list, or a custom HTML block. Open the Widget Manager, create a new widget, and choose its type. Place a widget on a page by inserting its shortcode into the page content or by assigning it to a layout area such as the sidebar.

Each widget has display options like the number of items and sorting. Disable a widget to hide it without deleting it. Custom HTML widgets can contain scripts, so only trusted administrators should be allowed to edit them.
