title: Webhooks and the API
url: local://fallback/webhooks-and-api

The platform offers an API and webhooks so other systems can react to events. Create an API key in the admin panel and send it in the request header. The API can read and create members and listings.

Webhooks send an HTTP POST request to a URL you provide when an event occurs, for example when a new member signs up or a lead is created. Enter the target URL, choose the events, and use the test button to send a sample request. Your server should reply with a success status within a few seconds. Tools such as Zapier can receive webhooks to connect your directory to other apps.
