title: Import Members from a CSV File
url: local://fallback/import-members-csv

You can bulk-load listings into your directory by importing a CSV file. Prepare a spreadsheet with one row per member and save it as CSV with a header row. Required columns are email, first name, last name, and company name. Optional columns include phone, address, website, and category.

Open the Import tool in the admin panel, upload the CSV file, and map each spreadsheet column to a member field. Run a test import with a small file first. The importer skips rows with a duplicate email address and reports them in a results summary. Imported members are created without a password; send them a password reset email so they can log in. Very large files should be split into batches of about 1000 rows.
