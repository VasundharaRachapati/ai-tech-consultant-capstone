title: Staff Accounts, Roles, and Permissions
url: local://fallback/user-roles-permissions

Administrators can create staff accounts with limited access. Open Staff Accounts, add a user, and assign a role. Roles define which admin areas the person can see, for example a moderator who can approve listings but cannot change payment settings.

Create a custom role by selecting the permissions it should include. Staff members log in with their own email and password. Remove access at any time by disabling the account. We recommend giving each person the least access they need.
