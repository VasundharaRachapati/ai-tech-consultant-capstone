title: Add a Google Maps API Key
url: local://fallback/google-maps-api-key

Map features such as the map layout of search results and the location picker for members need a Google Maps API key. Create a project in the Google Cloud console, enable the Maps JavaScript API and the Geocoding API, and create an API key. Restrict the key to your domain to prevent misuse.

Paste the key into Map Settings in the admin panel and save. If maps show a development purposes only watermark, billing is not enabled on your Google Cloud project. If maps are blank, check the browser console for a key restriction error.
