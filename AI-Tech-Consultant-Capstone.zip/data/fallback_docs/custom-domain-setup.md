title: Connect a Custom Domain
url: local://fallback/custom-domain-setup

To use your own domain name, such as www.example.com, point the domain to your site and then register it in the admin panel. At your domain registrar, create an A record or a CNAME record that points to the address shown in your Domain Settings page. DNS changes can take up to 48 hours to spread across the internet.

After DNS is working, enter the domain in Domain Settings and save. Choose whether the www version or the bare domain is the primary one; the other will redirect. If the domain does not load after 48 hours, double check the DNS record for typing mistakes and confirm that no old record conflicts with it.
