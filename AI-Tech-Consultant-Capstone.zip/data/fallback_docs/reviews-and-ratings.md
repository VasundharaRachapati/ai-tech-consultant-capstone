title: Member Reviews and Ratings
url: local://fallback/reviews-and-ratings

Visitors can leave star ratings and written reviews on member profiles. Turn reviews on in Review Settings. You can require visitors to confirm their email address and choose whether reviews are published immediately or held for moderation.

Moderate held reviews from the Reviews list by approving, editing, or deleting them. Members can be allowed to reply publicly to reviews. The average rating is shown in search results and can be used as a filter. Reviews can be exported to a CSV file.
