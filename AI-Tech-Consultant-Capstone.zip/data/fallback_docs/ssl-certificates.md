title: SSL Certificates and HTTPS
url: local://fallback/ssl-certificates

An SSL certificate encrypts traffic between visitors and your site and enables the HTTPS padlock in the browser. A free certificate is issued automatically after a custom domain is connected and its DNS record is correct. Issuance usually takes a few minutes but can take up to a few hours.

If visitors see a not secure warning, make sure the Force HTTPS option is enabled in Domain Settings and that images and scripts on your pages load over HTTPS rather than HTTP. If a certificate fails to issue, verify the DNS record and try the Reissue Certificate button.
